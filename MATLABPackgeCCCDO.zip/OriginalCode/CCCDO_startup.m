%% CCCDO_startup file to arrange package path
% This file adds Cell-Cycle-Chromatin-Dynamic-Organization(CCCDO) master
% folder to MATLAB path. User should save this file in his “C:\...\MATLAB”
% folder, and define this folder path as specified by variable: MATLABFolder
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%%%%%% start from clean workspace %%%%%%%%%%%%%%%%%%%%%
clear; close all; clc;
%% %%%%%%%%%% for first instulation only change to 1 %%%%%%%%%%%%%%%%%%%%%%
InstallRun = 0;
% InstallRun = 1;
%% %%%%%%%%%%%%%%%%%% target folder for installation %%%%%%%%%%%%%%%%%%%%%%
global TargetFolder
TargetFolder = ['Q:\Data and code from papers\2021 - Cell cycle dependent',...
    ' chromatin dynamic organization during the interphase'];
cd(TargetFolder);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%%% define MATLAB function folder %%%%%%%%%%%%%%%%%%%%%
global MATLABFolder
MATLABFolder = 'C:\Users\naortal\Documents\MATLAB';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% user do not need to modify the rest of this file %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%% add package folders to matlab path %%%%%%%%%%%%%%%%%%
global CCCDO_master
CCCDO_master = [MATLABFolder,'\CCCDO_master'];
addpath(CCCDO_master);
%% %%%%%%%%%%%%%%%%%%%% Open Main Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
open([CCCDO_master,'\UserParameter.m']);
open([MATLABFolder,'\CCCDO_startup.m']);
open([CCCDO_master,'\Main.m']);
%% %%%%%%%%% make Data storage folder if InstallRun is true %%%%%%%%%%%%%%%
if InstallRun==1
    % cell cycle phase names
    PhaseNames= {'G0','S','G2','LateG2','UT'};
    % cell lines names
    CellTypeName={'MEF3T3','MEFLmnaKO'};
    % parent folder name
    ParentFolderName = 'ExampleFolder';
    mkdir(TargetFolder,ParentFolderName);
    TargetFolder = [TargetFolder,'\',ParentFolderName];
    cd(TargetFolder);
    %%%%%%%%%%%%%%%%%%%%%%%% create experiment folders %%%%%%%%%%%%%%%%%%%%
    for j=1:numel(CellTypeName)
        
        for i=1:numel(PhaseNames)
            
            mkdir(TargetFolder,[CellTypeName{1,j},'_',PhaseNames{1,i}]);
            mkdir([TargetFolder,'\',CellTypeName{1,j},'_',PhaseNames{1,i}],...
                'Analysis');
            
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%% create ensemble MSD folders %%%%%%%%%%%%%%%%%%
    AnalysisName = {'Axial','Lateral','Full','SummaryAnalysis'};
    mkdir(TargetFolder,'EnsembleAnalysis');
    for k=1:4
        mkdir([TargetFolder,'\EnsembleAnalysis'],AnalysisName{1,k});
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
clearvars -except TargetFolder MATLABFolder CCCDO_master

%% %%%%%%%%%%%%%%%%%%%%%%%%%% end of file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%