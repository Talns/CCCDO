%% Main Function: Main
% This function handle all analysis runmodes 
%% %%%%%%%%%%%%%%%%%%%% Run mode discription %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% SingleRun: single cell analysis %%%%%%%%%%%%%%%%%%%%%%%%
% calculate MSD vectors for each cell separately in a specific experiment
%%%%%%%%%%%%%%%%%%%%%% GeneralRun: single experiment %%%%%%%%%%%%%%%%%%%%%%
% This function summarizes all trajectories data from single experiment
%%%%%%%%%%%%%%%%%%%%%% EnsembleRun: Ensemble MSD analysis %%%%%%%%%%%%%%%%%
% This function calculates anomalous exponent and diffusion coefficient.
% compare between cell cycle phase and between cell lines (MEF 3T3 and MEF
% LmnaKO)
%%%%%%%%%%%%%%% LateralMSD: lateral analysis single experiment %%%%%%%%%%%%
% This function summarizes all trajectories data from single experiment.
% using only Lateral (x,y) data.
%%%%%%%%%%%%%%%%%% AxialMSD: axial analysis single experiment %%%%%%%%%%%%%
% This function summarizes all trajectories data from single experiment.
% using only Axial (Z) data.
%%%%%%%%%%%%%%%%%%% SummaryRun- convex hull analysis %%%%%%%%%%%%%%%%%%%%%%
% This function calculates the " constraining volume"- the mean volume
% "visited" by a random telomere in each phase of the cell cycle. This
% value represents the constraint level of the specific cell cycle phase. 
%%%%%%%%%%%%%%%%%%%%%% GeneralQC- statistical tests and QC %%%%%%%%%%%%%%%%
% see user guide 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function varargout = Main(varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% user dialog box for choose rum mode
RunModes={'SingleRun','GeneralRun','EnsembleRun',...
    'LateralMSD','AxialMSD','SummaryRun','GeneralQC'};
if ~isempty(varargin)
    n=varargin{1};
else
    [n,~] = listdlg('PromptString','choose type of analysis',...
        'SelectionMode','single','ListString',RunModes);
    fprintf(['Runing mode: ',RunModes{1,n},'\n']);
end
RunModeNow=RunModes{1,n};
%% Axillary call
idx={0,6};
[~,~,~,~,~,~,~,PhaseNames,CellTypeName,~] = UserParameter(idx);
%% import user defined parameteres
if ~ismember(n,[3,6,7])
    % user dialog box
    idx=cell(1,2);
    [idx{1,1},~] =...
        listdlg('PromptString','choose cell cycle phase',...
        'SelectionMode','single','ListString',PhaseNames);
    [idx{1,2},~] =...
        listdlg('PromptString','choose cell line name',...
        'SelectionMode','single','ListString',CellTypeName);
    
    fprintf(['processing: ',CellTypeName{1,idx{1,2}},...
        ' ',PhaseNames{1,idx{1,1}},'\n']);
    % import user parameters 
    UDparam=struct();
    [UDparam.ExperimentFolder,UDparam.CellType,UDparam.ExcludedCells,...
        UDparam.numCells,UDparam.Phaseidx,UDparam.NumFrames,UDparam.MinLength,...
        UDparam.PhaseNames,UDparam.CellTypeName,~] = ...
        UserParameter(idx);
elseif n==3
    AnalysisType = {'Axial(Z)','Lateral(xy)','3D analysis'};
    [Dimensionality,~] =...
        listdlg('PromptString','choose type of ensemble MSD analysis',...
        'SelectionMode','single','ListString',AnalysisType);
    fprintf(['Running: ',AnalysisType{1,Dimensionality},...
        ' ensemble MSD analysis\n' ]);
elseif n==7
    % Tasks list for QC analysis
    QTTaskList={'generate linear fit figure for each trajectory',...
        'exclude bad fitted trajectories',...
        'Statistical tests: significance and table of statistical parameter',...
        'generate trajectories color figure with X,Y,Z'};
    % user decision
    [QCTask,~] =...
        listdlg('PromptString','choose type of ensemble MSD analysis',...
        'SelectionMode','single','ListString',QTTaskList);
    if QCTask == 1
        AnalysisType = {'Axial(Z)','Lateral(xy)','3D analysis'};
        [Dimensionality,~] =...
            listdlg('PromptString','choose type of ensemble MSD analysis',...
            'SelectionMode','single','ListString',AnalysisType);
    end
    if QCTask == 2
        % user dialog box
        idx=cell(1,2);
        [idx{1,1},~] =...
            listdlg('PromptString','choose cell cycle phase',...
            'SelectionMode','single','ListString',PhaseNames);
        [idx{1,2},~] =...
            listdlg('PromptString','choose cell line name',...
            'SelectionMode','single','ListString',CellTypeName);
        fprintf(['processing: ',CellTypeName{1,idx{1,2}},...
        ' ',PhaseNames{1,idx{1,1}},'\n']);
    
        UDparam=struct();
        [UDparam.ExperimentFolder,UDparam.CellType,UDparam.ExcludedCells,...
            UDparam.numCells,UDparam.Phaseidx,UDparam.NumFrames,UDparam.MinLength,...
            UDparam.PhaseNames,UDparam.CellTypeName,~] = ...
            UserParameter(idx);
    end
end

%% %%%%%%%%%%%%%%%%%%%%%%% Run mode calling %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch RunModeNow
    %% %%%%%%%%%%%%%%%%%%% single cell analysis %%%%%%%%%%%%%%%%%%%%%%%
    case 'SingleRun'
        for i=1:UDparam.numCells
            if ismember(i,UDparam.ExcludedCells)
                continue;
            else
                ThisCell=i;
                fprintf(['Analyzing cell: ',num2str(i),'\n']);
                AnalysisResults = CCCDO(1,UDparam,ThisCell);
                varargout{1} = AnalysisResults;
            end
        end
        close all
        %% %%%%%%%%%%%%%%% general analysis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 'GeneralRun'
        
        ExperimentTitle=['',CellTypeName{1,idx{1,2}},...
            ' ',PhaseNames{1,idx{1,1}},' phase'];
        DataFolder=[];
        GeneralAnalysisResults = ...
            CCCDO(2,UDparam,ExperimentTitle,DataFolder).Results;
        varargout{1} = GeneralAnalysisResults;
        %% %%%%%%%%%%%%%%%% Ensemble MSD analysis %%%%%%%%%%%%%%%%%%%%%%%%%
    case 'EnsembleRun'
        
        
        % defualt calling
        UDparam=struct();
        idx={0,3};
        [UDparam.ExperimentFolder,UDparam.CellType,UDparam.ExcludedCells,...
            UDparam.numCells,UDparam.Phaseidx,UDparam.NumFrames,...
            UDparam.MinLength,...
            UDparam.PhaseNames,UDparam.CellTypeName,DATAFolders] = ...
            UserParameter(idx,Dimensionality);
        EnsembleResults = ...
            CCCDO(3,UDparam,...
            DATAFolders,UDparam.ExperimentFolder,Dimensionality);
        varargout{1} = EnsembleResults;
        %% %%%%%%%%%%%%%% Lateral general analysis %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 'LateralMSD'
        
        UDparam.ExperimentFolder=['',UDparam.ExperimentFolder,'\Analysis'];
        LateralMSD = CCCDO.Main2D(UDparam.ExperimentFolder,...
            UDparam.ExcludedCells,UDparam.numCells);
        varargout{1} = LateralMSD;
        %% %%%%%%%%%%%%%% Axial general analysis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 'AxialMSD'
        UDparam.ExperimentFolder=['',UDparam.ExperimentFolder,'\Analysis'];
        AxialMSD = CCCDO.MainZ(UDparam.ExperimentFolder,...
            UDparam.ExcludedCells,UDparam.numCells);
        varargout{1} = AxialMSD;
        %% %%%%%%%%%%%%%% constraining volume analysis %%%%%%%%%%%%%%%%%%%%%%%%
    case 'SummaryRun'
        fprintf('Running: Constraining volume analysis\n');
        % user define parameters
        UDparam=struct();
        idx={0,4};
        [UDparam.ExperimentFolder,UDparam.CellType,UDparam.ExcludedCells,...
            UDparam.numCells,UDparam.Phaseidx,UDparam.NumFrames,...
            UDparam.MinLength,...
            UDparam.PhaseNames,UDparam.CellTypeName,TimeAve] = ...
            UserParameter(idx,[]);
        % call class
        CCCDO.ConvexHullAnalysis(TimeAve);
        %% %%%%%%%%%%%%%%%%% Quality control analysis %%%%%%%%%%%%%%%%%%%%%%%%%
    case 'GeneralQC'
                        
        switch QCTask
            case 1
                %%%%% generate linear fit figure for each trajectory %%%%%%
                MaxT=300;
                switch Dimensionality
                    case 1
                        CCCDO.GenerateLinaearFigSCAxial(MaxT);
                    case 2
                        CCCDO.GenerateLinaearFigSCLateral(MaxT);
                    case 3
                        CCCDO.GenerateLinaearFigSC(MaxT);
                end
            case 2
                %%%%% exclude bad fitted trajectories %%%%%%%%%%%
                CCCDO.RemoveTrj(idx);
                
            case 3
                %%%%%%%%%%%%% table of statistical parameter %%%%%%%%%%%%%%
                idx={0,5};
                [~,~,~,~,~,~,~,PhaseNames,CellTypeName,FolderName] =...
                    UserParameter(idx,[]);
                StatisticsMat = CCCDO.ExtractStatistics...
                    (FolderName,PhaseNames,CellTypeName);
                varargout{1} = StatisticsMat;
            case 4
                msgbox({'customable QC analysis';...
                    'add here your own QC function'},...
                    'message','help');

        end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
