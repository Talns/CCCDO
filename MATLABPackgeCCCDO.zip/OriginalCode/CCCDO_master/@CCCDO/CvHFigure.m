%% Figure Function: CvHFigure
% This function plots a trajectory with it's associated constraining volume
% calculated using convex hull.
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       CVH:            convex hull calculated for each trajectory.
%                       architecture: cell 1 by 3; while:
%                       {1,1}-axial(y,z),{1,2}-lateral(x,y),{1,3}-3D(x,y,z).
%                       CVH{i,j}- cell lines(i) by phases (j). each has k
%                       trajectories, while empty cell {[]} separate
%                       between the original source nucleus.
%                       CVH{i,j}{1,k}- convex hull; 
%                       CVH{i,j}{2,k}- trajectory;
%       Dimensionality: 1-Axial, 2- lateral, 3- 3D
%       idx:            indexes: {1,1} cell type, {1,2} phase, {1,3} trj.
%       FolderName:     directory to save figures. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:           no outputs for this function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function CvHFigure(CVH,Dimensionality, idx,FolderName)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Limits = [-0.3 0.3];
T=250;
time = [1:T];
% encode time to colormap
cm = jet(length(time));
colormap(cm);
color_scale = linspace(0,size(cm,1),numel(time));
V  = [];
Trj = [];
if isempty(CVH{1,3}{idx{1,1},idx{1,2}}{1,idx{1,3}})
    return
end
figure(1000*Dimensionality + idx{1,3});
V   = CVH{1,3}{idx{1,1},idx{1,2}}{1,idx{1,3}}; % convex hull
Trj = CVH{1,3}{idx{1,1},idx{1,2}}{2,idx{1,3}}; % trajectory
x = Trj(1:T,1)- nanmean(Trj(1:T,1));
y = Trj(1:T,2)- nanmean(Trj(1:T,2));
z = Trj(1:T,3)- nanmean(Trj(1:T,3));

h1 = surf([x,x],[y,y],[z,z],[color_scale',color_scale'],...
    'EdgeColor','flat', 'FaceColor','none');
hold on
h2 = trisurf(V,x,y,z,...
    'FaceColor','black','FaceAlpha',0.05);
axis equal
% project convex hull on plans 
% project xy 
hxy = trisurf(V,x,y,0.*z-Limits(2),...  
    'FaceColor','black','FaceAlpha',0.25,'LineStyle','none');
hxy1 = surf([x,x],[y,y],[z,z].*0-Limits(2),[color_scale',color_scale'],...
    'EdgeColor','flat', 'FaceColor','none');
% project xz
hxz = trisurf(V,x,0.*y+Limits(2),z,...   
    'FaceColor','black','FaceAlpha',0.25,'LineStyle','none');
hxz1 = surf([x,x],[y,y].*0+Limits(2),[z,z],[color_scale',color_scale'],...
    'EdgeColor','flat', 'FaceColor','none');
% project yz
hyz = trisurf(V,0.*x+Limits(2),y,z,...  
    'FaceColor','black','FaceAlpha',0.25,'LineStyle','none');
hyz1 = surf([x,x].*0+Limits(2),[y,y],[z,z],[color_scale',color_scale'],...
    'EdgeColor','flat', 'FaceColor','none');
xlim(Limits);
ylim(Limits);
zlim(Limits);
xlabel('X [\mu m]');
ylabel('Y [\mu m]');
zlabel('Z [\mu m]');
set(gcf,'position',[460 106 1440 872]);
FileName = ['CVh_',num2str(idx{1,3})];
grid on
saveas(gcf,[FolderName,'\',FileName],'bmp');
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
