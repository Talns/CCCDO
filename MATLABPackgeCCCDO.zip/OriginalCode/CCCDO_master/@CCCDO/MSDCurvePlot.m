%% Figure Function: DataCurvePlot
% This function plot MSD Data curve
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       FigParameter    struct with at least the following fields: 
%          .CellType    cell line MEF3T3 or MEFLmnaKO
%          .CurrentCell cell number
%          .FigIdx      logical index: 1- drow figure, and 0- Figure not
%                       requiered
%          .EdgeTerms   vector with two enries: first is the number of
%                       frames for tau=7sec, and the secound is the index 
%                       of lest time need to be include for linear fit curve
%       TauVec          time vector with units [sec]
%       Data             Mean Squere Displacment vector with unit: [um^2]
%                       double{time,Telomere#}
%       ExcludedTrj:    index vector of trajectories to be excluded 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:           No output for this function 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function MSDCurvePlot(FigParameter,TauVec,Data)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% save current folder path
currentFolder = pwd;
old=currentFolder;
% make new folder to save figures
mkdir(currentFolder,['',FigParameter.CellType,...
    '_',num2str(FigParameter.CurrentCell),'_Data_Figures']);
% goto new folder
cd([currentFolder,'\\','',FigParameter.CellType,...
    '_',num2str(FigParameter.CurrentCell),'_Data_Figures']);
Limit=[min(min(Data)) max(max(Data))];
for i=1:size(Data,2)% fore each telomere

    figure('name',['',FigParameter.CellType,...
        '_',num2str(FigParameter.CurrentCell),...
        ' telomere_',num2str(i)],'NumberTitle','off');
    loglog(TauVec,Data(:,i),'*k');
        xlabel('time[sec]','fontsize',16);
    ylabel('MSD [\mu m^2]','fontsize',16);
    ylim(Limit);
    xlim([0 200]);
    title(['',FigParameter.CellType,...
        '-',num2str(FigParameter.CurrentCell),...
        ' telomere-',num2str(i)]);
    % save figure
    saveas(gcf,['',FigParameter.CellType,...
        '_',num2str(FigParameter.CurrentCell),...
        ' telomere_',num2str(i)],'bmp');
end
cd(old);
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
