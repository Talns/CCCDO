%% Pipeline Function: TauCutoffFind
% This function calculates the transition times according to De Gennes model
% of reptation for single phase  
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       MSD:               MSD vectors of all trajectories in this phase
%       MaxT:              Last frame to be included for MSD calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       TransitionTime:    transition times (in frames).  
%                          1st column: glass-rubber transition 
%                          2nd column: rubber-liquid transition 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function TransitionTime = TauCutoffFind(MSD,MaxT)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MMSD=mean(MSD(:,:,1),2,'omitnan');
tau=[1:1500].*0.1;
MinLength=150;
FigParameter=struct();
FigParameter.CellType=[];
FigParameter.CurrentCell=0;
FigParameter.FigIdx=0;

%% find 1st transition time
AlphaD=[];
fprintf('find 1st transition time\n');
for k=10:MaxT
    FigParameter.EdgeTerms=[k,MaxT+MinLength];
    temp = CCCDO.BiLinearFitPlot(FigParameter,tau,MMSD,MinLength);
    AlphaD=vertcat(AlphaD,temp(:,:,1));
end
Tr=find(AlphaD(:,1)<=0.25,1,'last');
%% find 2nd transition time
AlphaD=[];
fprintf('find 2nd transition time\n');
for k=(MaxT-MinLength):-1:10
    FigParameter.EdgeTerms=[k,MaxT+MinLength];
    temp = CCCDO.BiLinearFitPlot(FigParameter,tau,MMSD,MinLength);
    AlphaD=vertcat(AlphaD,temp(:,:,2));
end
TL=find(AlphaD(:,3)<=0.9,1,'last');
TL=MaxT-MinLength-TL;
%% validate no collision between transition times
if isempty(Tr)
    Tr=10;
end

if TL>=Tr
    TransitionTime=[Tr,TL];
elseif Tr >= (MaxT-MinLength)
    TransitionTime=[MaxT-MinLength-50,MaxT-MinLength];
elseif TL >= (MaxT-MinLength)
    TransitionTime=[Tr,MaxT-MinLength];
else
    TransitionTime=[Tr,Tr+(MinLength/2)];
end


%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
