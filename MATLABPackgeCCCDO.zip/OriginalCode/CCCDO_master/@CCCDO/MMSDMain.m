%% Auxiliary Function: MMSDMain
% This function handle ensemble MSD figure generation by calling figure
% functions. 
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       FolderName:         path for saving the figures 
%       MSD:                struct with field equal to PhasesName; each one of
%                           them is struct with field {'MEF3T3','MEFLmnaKO'}
%                           with MSD vectors of all trajectories in this phase
%       Dimensionality:     type of analysis: 
%                               1- Axial(Z), 2- Lateral(xy),3- 3D analysis
%       MaxT:              Last frame to be included for MSD calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:           no output for this function  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function MMSDMain(FolderName,MSD,Dimensionality,MaxT)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define local parameters 
PhasesNames={'G0','S','G2','LateG2','UT'};
CellType={'MEF3T3','MEFLmnaKO'};
if isfolder(['',FolderName,'\MMSD'])
    cd(['',FolderName,'\MMSD'])
else
    mkdir(FolderName,'MMSD')
    cd(['',FolderName,'\MMSD'])
end
%% the two cell lines without msd area 
CCCDO.MMSD2(PhasesNames,CellType,MSD,Dimensionality,MaxT); 
%% all phase without area std
 idx=cell(1,3);
 idx{1,2}=0;
 idx{1,3}=0;
 for j=1:2
 idx{1,1}=j;
 CCCDO.MeanMSDFig(PhasesNames,CellType,MSD,idx,Dimensionality,MaxT);
 end
 %% each phase in seperate subplot with area std
 idx=cell(1,3);
 idx{1,2}=1;
 idx{1,3}=0;
 for j=1:2
 idx{1,1}=j;
 CCCDO.MeanMSDFig(PhasesNames,CellType,MSD,idx,Dimensionality,MaxT);
 end
 %% figure for each phase to each cell line 
 idx=cell(1,3);
 idx{1,2}=1;
 for j=1:2
     idx{1,1}=j;
     for i=1:5
         idx{1,3}=i;
         CCCDO.MeanMSDFig(PhasesNames,CellType,MSD,idx,Dimensionality,MaxT);
     end
 end
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
