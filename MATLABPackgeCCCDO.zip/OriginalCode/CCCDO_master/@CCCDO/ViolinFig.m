%% Figure Function: ViolinFig
% This function generates violin figure for the anomalous exponent
% distribution data in all cell cycle phases according to transition times
% detected by the ensemble MSD vectors.
%% credit declaration/citation: 
% this function using modified version of   Hoffmann H, 2015: violin.m
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       FolderName:         path for saving the figures
%       PhasesName:         cell array with phases names
%                           {'G0','S','G2','LateG2','UT'}
%       CellTypeNameName:   cell array with cell lines names
%                           {'MEF3T3','MEFLmnaKO'}
%       CoefficientVec:     struct with field equal to PhasesName;
%                             each one of them is struct with fields
%                             {'MEF3T3','MEFLmnaKO'}
%                             double matrix {telomere#,[alpha,D,GOF],3}
%                             while:  row- number of telomeres
%                                     column 1: anomalous exponent
%                                     column 2: diffusion coefficient
%                                     column 3: goodness of the fit
%                                     (:,:,1)    tau<Tr
%                                     (:,:,2)    tau>TL
%      CaseRun:             cell array; if {1,1}=1, violin plot for the
%                           cell line specified by {1,2} is plotted. if
%                           {1,1}=2 figures for each time areas are
%                           created.
%                           {1,1}=3 figure of D* is plotted for t<time
%                           renewal. 
%      Dimensionality:      type of analysis: 
%                           1- Axial(Z), 2- Lateral(xy),3- 3D analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:               no outputs for this function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% script starts here %%

function ViolinFig(FolderName,PhasesName,CellTypeName,...
    CoefficientVec,CaseRun,Dimensionality)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd(FolderName);
switch CaseRun{1,1}
    %% case 1: generate violin plot for specific cell line
    case 1
        colornames={'b','g','m','r','k'};
        Y=cell(1,5);
        j=CaseRun{1,2};
        TitleNames={'t<\tau_r','t>\tau_L'};
        FigureName=['',CellTypeName{1,j},' violin'];
        figure('name',FigureName,'NumberTitle','off');
        for k=1:2 % short and long time
            for i=1:5 % collect each phase data

                eval(['Y{1,i} = CoefficientVec.',PhasesName{1,i},...
                    '.',CellTypeName{1,j},'(:,1,k);']);
                
            end
            
            subplot(1,2,k);
            [h,L,MX,MED,bw]=CCCDO.violin(Y,colornames,'facealpha',0.25,'bw',0.1);
            xticklabels(PhasesName);
            ylabel('anomalous exponent (\alpha)','fontsize',14);
            title(TitleNames{1,k});
            legend('off');
            ylim([0 2]);
            fprintf(['',FigureName,' Kernel bandwidth: ',...
                num2str(max(bw),'%.e'),'\n']);
            ax = gca;
            ax.FontSize = 18;
            box off
        end
        suptitle(['',CellTypeName{1,j}]);
        set(gcf,'position',[453 229 1039 628]);
        saveas(gcf,['',CellTypeName{1,j},'_Violin'],'bmp');
        
        %% case 2: generate violin plot for both cell lines for each time span
    case 2
        colornames={'b','b','g','g','m','m','r','r','k','k'};
        Y1=cell(1,10);
        Y2=cell(1,10);
        TitleNames={'Low','High','t<\tau_r','t>\tau_L'};
        % collect data
        n=0;
        for i=1:5
            eval(['Y1{1,i+n} = CoefficientVec.',PhasesName{1,i},...
                '.',CellTypeName{1,1},'(:,1,1);']);
            eval(['Y1{1,i+n+1} = CoefficientVec.',PhasesName{1,i},...
                '.',CellTypeName{1,2},'(:,1,1);']);
%             if i==1||i==5
%                 eval(['Y2{1,i+n} = CoefficientVec.',PhasesName{1,i},...
%                     '.',CellTypeName{1,1},'(:,1,3);']);
%                 eval(['Y2{1,i+n+1} = CoefficientVec.',PhasesName{1,i},...
%                     '.',CellTypeName{1,2},'(:,1,3);']);
%             else
                eval(['Y2{1,i+n} = CoefficientVec.',PhasesName{1,i},...
                    '.',CellTypeName{1,1},'(:,1,2);']);
                eval(['Y2{1,i+n+1} = CoefficientVec.',PhasesName{1,i},...
                    '.',CellTypeName{1,2},'(:,1,2);']);
%             end
            n=n+1;
        end
        for k=1:2
            FigureName=['',TitleNames{1,k}];
            figure('name',FigureName,'NumberTitle','off');
            eval(['temp=Y',num2str(k),';']);
            [h,L,MX,MED,bw]=CCCDO.violin(temp,colornames,'facealpha',0.25,'bw',0.1);
            ylim([0 2]);
            xticks([1:0.5:10]);
            xticklabels({'','G0','','','','S','','','','G2',...
                '','','','LateG2','','','','UT',''});
            ylabel('anomalous exponent (\alpha)','fontsize',14);
            ax = gca;
            ax.FontSize = 18;
            box off
            title(['',TitleNames{1,k+2}]);
            set(gcf,'position',[246 147 790 645]);
            saveas(gcf,['',TitleNames{1,k},'_violin'],'bmp');
            fprintf(['',FigureName,' Kernel bandwidth: ',...
                num2str(max(bw),'%.e'),'\n']);
        end
    %% case 3: D* for the shorter times     
    case 3
        colornames={'b','g','m','r','k'};
        Y=cell(1,5);
        
        for i=1:5
            eval(['Y{1,i} = CoefficientVec.',PhasesName{1,i},...
                '.',CellTypeName{1,1},'(:,2,1);']);
            
        end
        figure('name','total mobility coefficient','NumberTitle','off');
        [h,L,MX,MED,bw] = CCCDO.violin(Y,colornames,'facealpha',0.25);
        if Dimensionality~=3
            ylim([0 0.1]);
        else
            ylim([0 0.025]);
        end
        xticks([1:0.5:10]);
        xticklabels({'G0','','S','','G2','','LateG2','','UT'});
        L.Location='southoutside';
        L.NumColumns=2;
        yticks([0:0.005:0.25]);
        if Dimensionality==3
            yticklabels({'0','5x10^-^3','10x10^-^3','15x10^-^3',...
                '20x10^-^3','25x10^-^3'});
        else
            yticklabels({'0','','10x10^-^3','',...
                '20x10^-^3','','30x10^-^3','','40x10^-^3',...
                '','50x10^-^3','','60x10^-^3','','70x10^-^3','','80x10^-^3',...
                '','90x10^-^3','','100x10^-^3'});
        end
        ylabel('D_\alpha [\mu m^2/sec^\alpha]','fontsize',14);
        ax = gca;
        ax.FontSize = 18;
        box off
        title('Total mobility coefficient for t<\tau_r');
        fprintf(['total mobility coefficient Kernel bandwidth: ',...
            num2str(max(bw),'%.e'),'\n']);
        set(gcf,'position',[519 223 839 734]);
        saveas(gcf,'DalphaLow','bmp');
    case 4
        colornames={'b','b','g','g','m','m','r','r','k','k'};
        Y=cell(1,10);
        n=0;
        for i=1:5
            eval(['Y{1,i+n} = CoefficientVec.',PhasesName{1,i},...
                '.',CellTypeName{1,1},'(:,2,1);']);
            eval(['Y{1,i+n+1} = CoefficientVec.',PhasesName{1,i},...
                '.',CellTypeName{1,2},'(:,2,1);']);
            n=n+1;
        end
        figure('name','total mobility coefficient','NumberTitle','off');
        [h,L,MX,MED,bw]=CCCDO.violin(Y,colornames,'facealpha',0.25);
        if Dimensionality~=3
            ylim([0 0.1]);
        else
            ylim([0 0.025]);
        end
        xticks([1:0.5:10]);
        xticklabels({'','G0','','','','S','','','','G2',...
            '','','','LateG2','','','','UT',''});
        L.Location='southoutside';
        L.NumColumns=2;
        yticks([0:0.005:0.25]);
        if Dimensionality==3
            yticklabels({'0','5x10^-^3','10x10^-^3','15x10^-^3',...
                '20x10^-^3','25x10^-^3'});
        else
            yticklabels({'0','','10x10^-^3','',...
                '20x10^-^3','','30x10^-^3','','40x10^-^3',...
                '','50x10^-^3','','60x10^-^3','','70x10^-^3','','80x10^-^3',...
                '','90x10^-^3','','100x10^-^3'});
        end
        ylabel('D_\alpha [\mu m^2/sec^\alpha]','fontsize',14);
        ax = gca;
        ax.FontSize = 18;
        title('Total mobility coefficient for t<\tau_r');
        fprintf(['total mobility coefficient Kernel bandwidth: ',...
            num2str(max(bw),'%.e'),'\n']);
        set(gcf,'position',[519 223 839 734]);
        saveas(gcf,'DalphaLow','bmp');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
