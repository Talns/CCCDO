%% Pipeline Function: CalculateMSD
% This function calculates MSD vector for each trajectory.   
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       Data:           Trajectories coordinates (x,y,z,amp). "Data" may be
%                       matrix or struct with field name Trajectories 
%       IntervalTime:   time steps between frames in sec
%       FinalFrame:     number of time points
%       Dimensionality: 1-calculate axial(Z) MSD, 2- calculate lateral(xy)
%                       MSD, 3- calculate 3D MSD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       TauVec:         time vector in sec
%       MSDVec:         Double M by N by 5 while: 
%                       rows: time points 
%                       columns: trajectories 
%                       (:,:,1) MSD values
%                       (:,:,2) pairs count in each time point
%                       (:,:,3) standard deviation
%                       (:,:,4) t-test low value
%                       (:,:,5) t-test high value
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function [TauVec,MSDVec] = ...
    CalculateMSD(Data,IntervalTime,FinalFrame,Dimensionality)

%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define parameters 
TimePointNum=FinalFrame;    % number of time point
% if data is matrix- change to struct
if ~isstruct(Data)
    eval('temp.Trajectories = Data;');
    Data=temp;
end
NumOfTelomeres=size(Data.Trajectories,1);  % number of telomeres
MSDVec=zeros(TimePointNum,NumOfTelomeres,5);
TauVec=(1:TimePointNum).*IntervalTime;  % time vector [sec]
for k=1:NumOfTelomeres
    switch Dimensionality
        case 1
            r=Data.Trajectories(k,3,:); % Axial position vector
        case 2
            x=Data.Trajectories(k,1,:); % x co-ordinates
            y=Data.Trajectories(k,2,:); % y co-ordinates
            r = sqrt(x.^ 2+ y.^2);      % calculate positions vector
            
        case 3
            x=Data.Trajectories(k,1,:); % x co-ordinates
            y=Data.Trajectories(k,2,:); % y co-ordinates
            z=Data.Trajectories(k,3,:); % z co-ordinates
            r = sqrt(x.^ 2+ y.^2+z.^2); % calculate positions vector
    end
    r_square=zeros(1,TimePointNum); % MSD value
    sd=zeros(1,TimePointNum);       % standart diviation
    Low=zeros(1,TimePointNum);      % t-test low
    High=zeros(1,TimePointNum);     % t-test high
    paircounts=zeros(1,TimePointNum);   % pairs count vector
    for n=1:(TimePointNum-1) % build the R_squer vector for each time point
        TemporalRSQ=zeros(1,TimePointNum-n);
        Counter=0;
        for m = 1:(TimePointNum-n) % calculte for single time point
            if ~isnan(r(m))&&~isnan(r(m+n))
                Counter= Counter+1;
                paircounts(n)=paircounts(n)+1;
                TemporalRSQ(Counter)=((r(m+n)-r(m)).^2);
            end
        end
        TemporalRSQ = TemporalRSQ(TemporalRSQ~=0)./IntervalTime;
        % t-test
        [h,p,ci,stats] = ttest(TemporalRSQ,mean(TemporalRSQ));
        % save values
        r_square(n)=sum(TemporalRSQ)./paircounts(n);
        if ~isempty(h)
            sd(n)=stats.sd;
            Low(n)=ci(1);
            High(n)=ci(2);
        else
            sd(n)=nan;
            Low(n)=nan;
            High(n)=nan;
        end
    end
    % write to output 
    MSDVec(:,k,1)=r_square(:); % MSD value
    MSDVec(:,k,2)=paircounts(:); % number of paires calculated the value
    MSDVec(:,k,3)=sd(:);         % standard deviation    
    MSDVec(:,k,4)=Low(:);        % t-test low     
    MSDVec(:,k,5)=High(:);       % t-test High
end
MSDVec(MSDVec==0)=nan; % gap points in the trajectories  
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
