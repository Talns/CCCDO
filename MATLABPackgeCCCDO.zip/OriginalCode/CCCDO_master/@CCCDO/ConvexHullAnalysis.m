%% QC Function: ConvexHullAnalysis
% This function use Convex Hull to calculate the scanning volume of each
% tragectory
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       ExperimentFolder:        Directory to load data. 
%       TimeAve:                 specific time in sec for calculate 
%                                the constraining volume. 
%       PhaseNames:              cell cycle phases. cell 1 by 5
%                                   {'G0','S','G2','LateG2','UT'}
%       CellTypeName:            cell line names.{'MEF3T3','MEFLmnaKO'} 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:                    No outputs for this function 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function ConvexHullAnalysis(TimeAve)
%## activate when finish ##%
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CVH = cell(1,3);
VcH = cell(1,3);
idx={0,6};
[ExperimentFolder,~,~,...
    ~,~,~,~,...
    PhaseNames,CellTypeName] = ...
    UserParameter(idx,[]);
%% Scaning time
T = TimeAve*10;
%% generate folder for saving figures, and change directory 
if ~isfolder('SummaryAnalysis')
    mkdir(ExperimentFolder,'SummaryAnalysis');
    cd([ExperimentFolder,'\SummaryAnalysis']);
else
    cd([ExperimentFolder,'\EnsembleAnalysis\SummaryAnalysis']);
end
%% load data if available

if exist('CvH.mat','file')
    load('CvH.mat');
else
    %% calculate volumes
    DataFig = cell(3,numel(CellTypeName));
    for Dimensionality=1:3
        fprintf(['Convex Hull analysis;  Dimensionality: ',...
            num2str(Dimensionality),'\n']);
        CVH{1,Dimensionality} = cell(numel(CellTypeName),numel(PhaseNames));
        VcH{1,Dimensionality} = cell(numel(CellTypeName),numel(PhaseNames));
        for i=1:numel(CellTypeName)
            for j=1:numel(PhaseNames)
                fprintf(['Convex Hull analysis: ',...
                    CellTypeName{1,i},' ', PhaseNames{1,j},'\n']);
                % load data
                load([ExperimentFolder,'\',CellTypeName{1,i},...
                    '_',PhaseNames{1,j},'\Analysis\GeneralAnalysisResults.mat'],...
                    'GeneralAnalysisResults');
                idx={j,i};
                [~,~,~,numCells,~,~,~,~,~] = UserParameter(idx,[]);
                Data = GeneralAnalysisResults.AllCellsData;
                tic
                [CVH{1,Dimensionality}{i,j},VcH{1,Dimensionality}{i,j}] = ...
                    CCCDO.CVHaux(T,numCells,Data,Dimensionality);
                DataFig{Dimensionality,i}{1,j} = ...
                    log10(VcH{1,Dimensionality}{i,j});
                toc
            end
        end
    end
    
    %% calculate significance
    Alpha = [0.2,0.05,0.01,0.001];
    VPvalueMat = cell(1,numel(CellTypeName));
    for n=1:numel(CellTypeName)
        VPvalueMat{1,n} = cell(1,3);
        for m=1:3
            VPvalueMat{1,n}{1,m}=...
                nan(numel(PhaseNames),numel(PhaseNames),length(Alpha));
            for k=1:length(Alpha)
                for i=1:numel(PhaseNames)
                    for j=1:numel(PhaseNames)
                        [h,p] = ...
                            ttest2(DataFig{m,n}{1,i},DataFig{m,n}{1,j},...
                            'Alpha',Alpha(k),'Vartype','unequal');
                        if h~=0
                            VPvalueMat{1,n}{1,m}(i,j,k) = h*p;
                        end
                    end
                end
            end
        end
    end
    %% calculate mean constraining volume
    MeanVcH = zeros(numel(CellTypeName),numel(PhaseNames),3);
    for k=1:3
        for i=1:numel(CellTypeName)
            for j=1:numel(PhaseNames)
                MeanVcH(i,j,k) = nanmean(VcH{1, k}{i, j});
            end
        end
    end
    save('CvH.mat','CVH','VcH','DataFig','VPvalueMat','MeanVcH');
end % end here the generation of the data if not exist
%% generate plot
for Dimensionality=1:3
    for i=1:2
        idx={Dimensionality,i};
        CCCDO.ViolinCVH(DataFig{Dimensionality,i},idx);
    end
end

    
%% %% very long run time - change for CvH single trajectory analysis %%%%%%
Fig=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Fig==1
    %%%%%%%%%%%%%%%%%%%%%%%%%%% create save folders %%%%%%%%%%%%%%%%%%%%%%%
    if ~isfolder([SaveFolder,'\CvH\Fig'])
        mkdir([SaveFolder,'\CvH'],'Fig');
        FolderName = cell(numel(CellTypeName),numel(PhaseNames));
        for j=1:numel(CellTypeName)  
            for i=1:numel(PhaseNames)
                
                mkdir([SaveFolder,'\CvH\Fig'],...
                    [CellTypeName{1,j},'_',PhaseNames{1,i}]);
                FolderName{j,i} = [SaveFolder,'\CvH\Fig\',...
                    CellTypeName{1,j},'_',PhaseNames{1,i}];
                
            end
        end
        cd([SaveFolder,'\CvH\Fig']);
        save([SaveFolder,'\CvH\Fig\FolderName.mat'],'FolderName');
        clear i j idx
    else
        cd([SaveFolder,'\CvH\Fig']);
        load([SaveFolder,'\CvH\Fig\FolderName.mat'],'FolderName');
    end
    %%%%%%%%%%%%%%%%% plot figures trajectory by trajectory %%%%%%%%%%%%%%%
    
    for i=1:numel(CellTypeName)
        for j=1:numel(PhaseNames)
            for k=1:numel(CVH{1,3}{i,j})
                idx = {i,j,k};
                Dimensionality = 3;
                CCCDO.CvHFigure(CVH,Dimensionality, idx,FolderName{i,j});
                close all
            end
            
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
