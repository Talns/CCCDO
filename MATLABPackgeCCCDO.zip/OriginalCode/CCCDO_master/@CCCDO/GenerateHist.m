%% Figure Function: GenerateHist
% plot histogram with two sieries according to input specification 
%% function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        DataVecors         Data for histogram plot; struct with fields:
%           .Values         sieries for histogram. double{N,1}
%           .MeanValue      the mean values 
%           .STDValue       the standard diviation value
%           .VarValue       the Variance value
%        TitlesInfo         specifiy titles strings; struct with fields:
%           .titles         figure title title string 
%           .AxisTitles     cellarray{1x2} with  axis label strings
%           .FigureName     string for the figure name 
%           .FileName       name of the figure file to be saved
%        Parameter          specifiy plot parameters; struct with fields:
%           .NumBins        number of bins
%           .Normalization  normalization method
%           .EdgeColor      bin edge color 
%           .BinWidth       the with of the bins 
%           .FigSaveFormat  format of the figure file 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        none               no outputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function  GenerateHist (DataVecors,TitlesInfo,Parameter)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('name',TitlesInfo.FigureName,'NumberTitle','off')

h1=histogram(DataVecors.Values,'FaceColor','b');
h1.NumBins=Parameter.NumBins;
h1.Normalization=Parameter.Normalization;
h1.EdgeColor=Parameter.EdgeColor;
h1.BinWidth=Parameter.BinWidth;


xlim([0 2]);
xticks(0:0.25:2);
legend('off');
xlabel([TitlesInfo.AxisTitles{1},' total tracked: {\color{blue}',...
    num2str(length(DataVecors.Values)),'}'],'fontsize',14);
ylabel(TitlesInfo.AxisTitles{2},'fontsize',14);
% define title string
title(['\fontsize{14} {\color{blue}',TitlesInfo.titles,'=',...
    num2str(DataVecors.MeanValue,'%.2f'),...
    '\pm ',num2str(DataVecors.STDValue,'%.2f'),...
    ' \color{black}; \sigma^2(',...
    ' \color{blue}',num2str(DataVecors.VarValue,'%.2f'),')}']);

saveas(gcf,TitlesInfo.FileName,Parameter.FigSaveFormat);
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end 
