%% Figure Function: ViolinCVH
% This function generate violin plot three types of constraining volume: 
% ellipsoid combines lateral and axial radiuses, V= (4/3)pi*(Rxy^2)*(Rz)
% spear base on lateral only information, V= (4/3)pi*(Rxy^3) 
% spear base on Axial only information, V= (4/3)pi*(Rz^3) 
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       idx:        task indexes; {1,1} type of figure {1,2} cell line
%       Data:       struct with 3 fields: {'Full','Lateral','Axial'};
%                   each field is a struct with 5 field, with phase names.
%                   while each one is struct with fields
%                   {'MEF3T3','MEFLmnaKO'}. each one is vector 
%                   of the constraining vector at specific time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:       no output for this function. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function ViolinCVH(Data,idx)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define local parameters
colornames={'b','g','m','r','k'};
FigureType={'AvAxial','AvLateral','CvH3D'};
PhasesName={'G0','S','G2','LateG2','UT'};
CellTypeName={'MEF3T3','MEFLmnaKO'};
%% generate figure
FigureName=['',CellTypeName{1,idx{1,2}},' ',FigureType{1,idx{1,1}}];
figure('name',FigureName,'NumberTitle','off');
% create the violin
[h,L,MX,MED,bw] = CCCDO.violin(Data,colornames,'facealpha',0.25,'bw',0.1);

switch idx{1,1}
    case 1
        % Axial area
        ylabel('A_c [\mu m^2]','fontsize',16);
        title(['Axial constraining Area ',CellTypeName{1,idx{1,2}}]);
        FileName = ['',CellTypeName{1,idx{1,2}},...
            '_constraining_Area_',FigureType{1,idx{1,1}}];
    case 2
        % Lateral area
        ylabel('A_c [\mu m^2]','fontsize',16);
        title(['Lateral constraining Area ',CellTypeName{1,idx{1,2}}]);
         FileName = ['',CellTypeName{1,idx{1,2}},...
            '_constraining_Area_',FigureType{1,idx{1,1}}];
    case 3
        % 3D volume
        ylabel('V_c [\mu m^3]','fontsize',16);
        title(['constraining volume ',CellTypeName{1,idx{1,2}}]);
        FileName = ['',CellTypeName{1,idx{1,2}},...
            '_constraining_volume_',FigureType{1,idx{1,1}}];
end

xticklabels(PhasesName);

fprintf(['',FigureName,' Kernel bandwidth: ',...
    num2str(max(bw),'%.e'),'\n']);
ax = gca;
ax.FontSize = 18;
ylim([-4 2]);
box off
set(gcf,'position',[453 229 1039 628]);
saveas(gcf,FileName,'bmp');

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
