%% Auxilairy Function: ArrengeAllData
% This function generate struct from all CSV file after linking analysis 
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       ExperimentFolder:       Directory of the current experiment
%       NumFrames:              Number of frames (timepoints)
%       ThisCell:               cell number 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       LinkData:    struct with fields:
%           .Trajectories:      double num of trjectories by 4 by num of
%                               frames
%                               row- trjectories
%                               columns- [x,y,z,amp] XYZ units:um ,
%                                        amp:0-800
%                               (:,:,3)- timepoints(frames)
%           .TrjLength:         vector with length of not nan data for each
%                               trjectory
%           .MSD:               double num of frames by 5 by num of
%                               trajectories;
%                               rows-frames 
%                               column {MSD,pairs counts,std,t test low,
%                               t test high}
%                               (:,:,3) trajectories
%           .AffineMat:         cell array 1 by number of frame. each cell 
%                               contains affine matrix of the relative frame
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function LinkData = ArrengeAllData (ExperimentFolder,NumFrames,ThisCell,MinLength)
%% %%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define output stract
LinkData=struct();
DataPath=['',ExperimentFolder,'\Analysis\Cell_',num2str(ThisCell)];
% arrange trajectories data
fprintf('arrange trajectories data\n');
[LinkData.Trajectories,LinkData.TrjLength] = CCCDO.ArrengeTrajectories...
    (ExperimentFolder,NumFrames,ThisCell,MinLength);
% arrange msds data
fprintf('arrange msds  data\n');
[LinkData.MSD,LinkData.MSDlength] = CCCDO.ArrengeMSDs...
    (ExperimentFolder,NumFrames,ThisCell,MinLength,LinkData.TrjLength);
% remove dispute between trajectories and MSD matrixes. excess trjectories,
% which exluded by threshold when MSDs were calculated will be deleted
if length(LinkData.MSDlength) < length(LinkData.TrjLength)
   LinkData.Trajectories = ...
       LinkData.Trajectories(1:length(LinkData.MSDlength),:,:);
end
% arrange affine matrixes array
fprintf('arrange affine matrixes array\n');
LinkData.AffineMat = CCCDO.ArrengeAffineMat...
(ExperimentFolder,NumFrames,ThisCell);

% save cell data
filename=[DataPath,'\Cell_',num2str(ThisCell),'_LinkData.mat'];
eval(['Cell_',num2str(ThisCell),'=LinkData;']);
save(filename,['Cell_',num2str(ThisCell)]);
%% figure: trajectory in time coded color
fprintf('generate figures\n');
mkdir(DataPath,'ColorFigFolder');
cd([DataPath,'\ColorFigFolder']);
for i=1:size(LinkData.Trajectories,1)
    %       titleStr        cell array with titles for the figure:
    %                       {1,1} figure window name
    %                       {1,2} figure title
    %                       {1,3} figure file name
    %                       {1,4} figure file format
    titleStr={};
    titleStr{1,1}= ['Cell ',num2str(ThisCell),' Trj ',num2str(i)];
    titleStr{1,2}= ['Cell ',num2str(ThisCell),' Trj ',num2str(i)];
    titleStr{1,3}= ['Cell_',num2str(ThisCell),'_Trj_',num2str(i)];
    titleStr{1,4}= 'bmp';
    % copy trajectory coordinate
    ThisTrjData=LinkData.Trajectories(i,1:3,:);
    ThisTrjData=permute(ThisTrjData,[3 2 1]);
    time=1:NumFrames;
    % plot and save figure
    CCCDO.TrjectoryColorFigFull(time,ThisTrjData,titleStr);
end
cd(DataPath);
close all
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
