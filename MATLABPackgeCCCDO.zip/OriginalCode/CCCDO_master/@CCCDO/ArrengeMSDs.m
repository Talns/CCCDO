%% Auxilary Function: ArrengeMSDs
% This function arrenge MSD data from CSV file  
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       ExperimentFolder:       Directory of the current experiment
%       NumFrames:              Number of frames (timepoints)
%       ThisCell:               cell number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       MSD:                    double num of frames by 5 by num of
%                               trajectories;
%                               rows-frames 
%                               column {MSD,pairs counts,std,t test low,
%                               t test high}
%                               (:,:,3) trajectories
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function [MSD,MSDlength] =...
    ArrengeMSDs (ExperimentFolder,NumFrames,ThisCell,MinLength,~)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define local parameters
ExperimentName=split(ExperimentFolder,'\');
ExperimentName=ExperimentName{end};
DataPath=['',ExperimentFolder,'\Analysis\Cell_',num2str(ThisCell)];

%read csv file
fprintf('read csv file\n');
[num,txt,~] = xlsread([DataPath,'\',...
    ['',ExperimentName,'_Cell_',num2str(ThisCell),'_msds.csv']]);
% make numeric array from all data 
data=[];
for i=2:length(txt)
temp=txt{i,8}; % t test value 
% convert to vector
temp=strrep(strrep(temp,'(','['),')',']');
temp=str2num(temp);
% add value to msds array
temp1=horzcat(num(i-1,:),temp);
% stack new line data
data=vertcat(data,temp1);
end
data=data(:,2:end);% remove cell index
% number of trajectories
NumTrjec=max(data(:,1));
MSD=nan(NumTrjec,5,NumFrames);
% enter data to matrix
fprintf('Build MSD vector\n');
for i=1:NumTrjec
    Thistrj=data(data(:,1)==i,:);
    for j=1:NumFrames
        if ismember(j,Thistrj(:,2))
            MSD(i,1,j)=Thistrj(Thistrj(:,2)==j,3);
            MSD(i,2,j)=Thistrj(Thistrj(:,2)==j,4);
            MSD(i,3,j)=Thistrj(Thistrj(:,2)==j,5);
            MSD(i,4,j)=Thistrj(Thistrj(:,2)==j,6);
            MSD(i,5,j)=Thistrj(Thistrj(:,2)==j,7);
        end
    end
end
% change nm to um
UnitScal=10^6;
MSD(:,1,:)=MSD(:,1,:)./UnitScal;
MSD(:,3:5,:)=MSD(:,3:5,:)./UnitScal;
% create output MSD vector
MSD=permute(MSD,[3 1 2]);% rearange output
TrjLength=zeros(NumTrjec,1);
for i=1:NumTrjec
    TrjLength(i)=length(find(~isnan(MSD(:,i,1))));
end
MSD=MSD(:,TrjLength>=MinLength,:);% remove sort trajectories
% calculate MSD length
MSDlength=zeros(size(MSD,2),1);
for i=1:size(MSD,2)
    MSDlength(i)=length(find(~isnan(MSD(:,i,1))));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
