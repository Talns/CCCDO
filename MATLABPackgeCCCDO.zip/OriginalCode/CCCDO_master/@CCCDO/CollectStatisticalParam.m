%% Auxiliary Function: CollectStatisticalParam
% This function load data files and arrange parameters matrix
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       DataFolders:         paths to load files with parameters
%       PhaseNames:          cell cycle phases. cell 1 by 5
%                            {'G0','S','G2','LateG2','UT'}
%       CellTypeName:        cell line names.{'MEF3T3','MEFLmnaKO'} 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       DATA:               struct with fields:
%           .1st level      fieldnames: Full,Lateral,Axial; each one is a
%                           struct with fields: 
%               .TransitionTime:    Transition time separate between short
%                                   times t<Tr and longer times t>TL; 
%                                   vector 5 by 2 by 2 while:
%                                   row- cell cycle phase
%                                   column- Tr,TL
%                                   (:,;,1)'MEF3T3',(:,;,2)'MEFLmnaKO'
%               .ParameterMat:      struct with field equal to PhaseNames;
%                                   each one of them is struct with fields
%                                   {'MEF3T3','MEFLmnaKO'}
%                                   matrix of parameters. while:
%                                   rows (Mean, variance, skewness, kurtosis)
%                                   column(Tau<Tr,tau>TL ) 
%                                   (:,:,1) alpha exponent
%                                   (:,:,2) D*
%               .Pearson:           pearson correlation mean values, 
%                                   vector 5 by 2 by 2 while:
%                                   row- cell cycle phase
%                                   column- <Tr,>TL
%                                   (:,;,1)'MEF3T3',(:,;,2)'MEFLmnaKO'
%               .Radius:            2 by 5 vector while: 
%                                   (1,:)'MEF3T3',(2,:)'MEFLmnaKO'
%                                   column- cell cycle phase
%       StatisticsMat:      struct with fields:
%           .1st level      fieldnames: Full,Lateral,Axial; each one is a
%                           struct with fields: 
%               .2nd level  fieldnames:'MEF3T3','MEFLmnaKO'; 
%                           each one is vector 14 by 5, while column- cell
%                           cycle phase and rows are:
%                           (1) Tr, (2)TL 
%                           anomalous exponent (3) short (4) long
%                           variance respectively (5) short (6) long
%                           std      respectively (7) short (8) long
%                           diffusion constant (9) mean (10) std
%                           for 1st level = 'Full' only
%                           (11) number of trajectories (12) mean Pearson 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function [DATA,StatisticsMat] = ...
    CollectStatisticalParam(DataFolders,PhaseNames,CellTypeName)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define local parameters
% output struct
DATA=struct();
% 1st level fields
Full=struct();
Lateral=struct();
Axial=struct();
DataTypeName={'Full','Lateral','Axial'};

% statistical matrix
StatisticsMat=struct();
%% collect all data from ensemble analysis

for k=1:3
    fprintf(['collect ',DataTypeName{1,k},'\n']);
    load([DataFolders{1,k},'\Results.mat'],'Results');
    % write transition times
    eval([DataTypeName{1,k},'.TransitionTime = Results.TransitionTime;']);
    % write parameteres matrix
    eval([DataTypeName{1,k},'.ParameterMat = Results.ParameterMat;']);
    % collect pearson, num of trajectories
    for i=1:5
        for j=1:2
            eval([DataTypeName{1,k},...
                '.Pearson(i,1,j) = nanmean(Results.GeneralCoVec.',...
                PhaseNames{1,i},'.',CellTypeName{1,j},'(:,3,1));']);
            eval([DataTypeName{1,k},...
                '.Pearson(i,2,j) = nanmean(Results.GeneralCoVec.',...
                PhaseNames{1,i},'.',CellTypeName{1,j},'(:,3,2));']);
            eval([DataTypeName{1,k},...
                '.Pearson(i,3,j) = nanstd(Results.GeneralCoVec.',...
                PhaseNames{1,i},'.',CellTypeName{1,j},'(:,3,1));']);
            eval([DataTypeName{1,k},...
                '.Pearson(i,4,j) = nanstd(Results.GeneralCoVec.',...
                PhaseNames{1,i},'.',CellTypeName{1,j},'(:,3,2));']);
            if k==1
                eval([DataTypeName{1,k},...
                    '.NumTrjectories(i,j) = size(Results.GeneralCoVec.',...
                    PhaseNames{1,i},'.',CellTypeName{1,j},',1);']);
            end
        end
    end
    clear Results i j
end

% save Data
DATA.Full=Full;
DATA.Lateral=Lateral;
DATA.Axial=Axial;
clear Full Lateral Axial

%% rearange data
fprintf('rearange data\n');
for k=1:3
    for j=1:2
        for i=1:5
            if k==1
                NumParam=12;
            else
                NumParam=10;
            end
            TempMat=zeros(NumParam,5);
            %%%%%%%%%%%%%%%%%%%%%%%%%% copy Tr,TL %%%%%%%%%%%%%%%%%%%%%%%%%
            % copy Tr
            eval(['TempMat(1,i)=DATA.',DataTypeName{1,k},...
                '.TransitionTime(i,1,j);']);
            TempMat(1,i)=floor(TempMat(1,i)./10);
            % copy TL
            eval(['TempMat(2,i)=DATA.',DataTypeName{1,k},...
                '.TransitionTime(i,2,j);']);
            TempMat(2,i)=floor(TempMat(2,i)./10);
            %%%%%%%%%%%%%%%%%%%%%%%%%% copy alpha %%%%%%%%%%%%%%%%%%%%%%%%%
            % low
            eval(['TempMat(3,i)= DATA.',DataTypeName{1,k},'.ParameterMat.',...
                PhaseNames{1,i},'.',CellTypeName{1,j},'(1,1,1);']);
            % high
            eval(['TempMat(4,i)= DATA.',DataTypeName{1,k},'.ParameterMat.',...
                PhaseNames{1,i},'.',CellTypeName{1,j},'(1,2,1);']);
            %%%%%%%%%%%%%%%%%%%%%%%%%% copy variance %%%%%%%%%%%%%%%%%%%%%%
            % low
            eval(['TempMat(5,i)= DATA.',DataTypeName{1,k},'.ParameterMat.',...
                PhaseNames{1,i},'.',CellTypeName{1,j},'(2,1,1);']);
            % high
            eval(['TempMat(6,i)= DATA.',DataTypeName{1,k},'.ParameterMat.',...
                PhaseNames{1,i},'.',CellTypeName{1,j},'(2,2,1);']);
            %%%%%%%%%%%%%%%%%%%%%%%%%% calculate std %%%%%%%%%%%%%%%%%%%%%%
            TempMat(7,i)=sqrt(TempMat(5,i));
            TempMat(8,i)=sqrt(TempMat(6,i));
            %%%%%%%%%%%%%%%%%%%%%%%%%% copy diffusion constant %%%%%%%%%%%%
            % mean
            eval(['TempMat(9,i)= DATA.',DataTypeName{1,k},'.ParameterMat.',...
                PhaseNames{1,i},'.',CellTypeName{1,j},'(1,1,2);']);
            % std
            eval(['TempMat(10,i)= sqrt(DATA.',DataTypeName{1,k},'.ParameterMat.',...
                PhaseNames{1,i},'.',CellTypeName{1,j},'(2,1,2));']);
            %%%%%%%%%%%%%% copy number of trajectories and pearson %%%%%%%%
            if k==1
                TempMat(11,i)=DATA.Full.NumTrjectories(i,j);
                TempMat(12,i)=DATA.Full.Pearson(i,1);
            end
            %%%%%%%%%%%%%%%%%%%%%%% write to output %%%%%%%%%%%%%%%%%%%%%%%
            eval(['StatisticsMat.',...
                DataTypeName{1,k},'.',CellTypeName{1,j},...
                ' (:,i)= TempMat(:,i);']);
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
