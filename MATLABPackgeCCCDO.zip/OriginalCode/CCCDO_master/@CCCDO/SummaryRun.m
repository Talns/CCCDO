%% Runmode Function: SummaryRun
% This function calculates the " constraining volume"- the mean volume
% "visited" by a random telomere in each phase of the cell cycle. This
% value represents the constraint level of the specific cell cycle phase. 
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       ExperimentFolder:               Directory to load data. 
%       TimeAve:                        specific time in sec for calculate 
%                                       the constraining volume. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       Results:                    struct with two fields
%           .ConstrainingRadius:        struct with 3 fields:
%                                       {'Full','Lateral','Axial'}; each
%                                       field is a struct with 5 field,
%                                       with phase names. while each one is
%                                       struct with
%                                       fields{'MEF3T3','MEFLmnaKO'}. each
%                                       one is vector of the constraining
%                                       vector at specific time
%           .MeanConstrainingRadius:    vector 4 by 5 by 3 while:
%                                       row 1,2 are the mean value
%                                       calculated from the vector
%                                       ConstrainingRadius and row 3,4 is
%                                       values calculated from the ensemble
%                                       MSD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function Results = SummaryRun (ExperimentFolder, TimeAve)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% define local parameters
% path for loading data
DataFolders=cell(1,3);
DataFolders{1,1} = [ExperimentFolder,'\Full'];
DataFolders{1,2} = [ExperimentFolder,'\Lateral'];
DataFolders{1,3} = [ExperimentFolder,'\Axial'];


%% generate folder for saving figures, and change directory 
if ~isfolder('SummaryAnalysis')
    mkdir(ExperimentFolder,'SummaryAnalysis');
    cd([ExperimentFolder,'\SummaryAnalysis']);
else
    cd([ExperimentFolder,'\SummaryAnalysis']);
end

%% import data 
if exist([ExperimentFolder,'\SummaryAnalysis\Results.mat'],'file')
    load('Results.mat','Results');
else
    Results = CCCDO.SummaryAux(DataFolders,TimeAve);
end

%% draw constraining volume ilustrations
fprintf('draw constraining volume ilustrations\n');
for n=1:4
CCCDO.DrawConstrainingVolume(Results.MeanConstrainingRadius,n);
end

%% generate violin plot for constraining volume 

for k=1:3
    for j=1:2
        idx= {k,j};
        CCCDO.ViolinCV(Results.ConstrainingRadius,idx);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
