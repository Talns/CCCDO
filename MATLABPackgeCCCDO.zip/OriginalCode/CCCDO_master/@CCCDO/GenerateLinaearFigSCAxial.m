%% QC Function: GenerateLinaearFigSCAxial
% This function generates linear fit figures, for each trajectory, cell by
% cell and for all phases and cell lines.
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       MaxT:                 Last frame to be included for calculation of
%                             MSD coefficients
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:                 No output for this function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function GenerateLinaearFigSCAxial(MaxT)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% define general parmetes

Dimensionality=1;

% import data folders path
idx{1,1}=0;
idx{1,2}=3;
[~,~,~,~,~,~,~,PhaseNames,CellTypeName, DATAFolders] = ...
    UserParameter(idx,0);


%% collect parameters for this experiment

for k=1:2
    for j=1:5
        idx{1,1}=j;
        idx{1,2}=k;
        [~,~,ExcludedCells,numCells,~,NumFrames,~,~,~,~] =... 
        UserParameter(idx,0);
        % import data
        load([DATAFolders{k,j},'\Analysis\Axial_TransitionTime.mat'],...
            'TransitionTime');
        load([DATAFolders{k,j},'\Analysis\AxialMSD.mat'], 'AxialMSD');
        load([DATAFolders{k,j},'\Analysis\GeneralAnalysisResults.mat'],...
            'GeneralAnalysisResults');
        % change to figure saving path
        if isfolder([DATAFolders{k,j},'\AxialLinearFig'])
            cd([DATAFolders{k,j},'\AxialLinearFig']);
        else
            mkdir(DATAFolders{k,j},'AxialLinearFig');
            cd([DATAFolders{k,j},'\AxialLinearFig']);
            mkdir([DATAFolders{k,j},'\AxialLinearFig'],'SuperDiffusion');
            mkdir([DATAFolders{k,j},'\AxialLinearFig'],'SubDiffusion');
            mkdir([DATAFolders{k,j},'\AxialLinearFig'],'ExtremeSubDiffusion');
            mkdir([DATAFolders{k,j},'\AxialLinearFig'],'Trj');
        end
        SaveFolderes = {[DATAFolders{k,j},'\AxialLinearFig\SuperDiffusion']...
            [DATAFolders{k,j},'\AxialLinearFig\ExtremeSubDiffusion'],...
            [DATAFolders{k,j},'\AxialLinearFig\SubDiffusion'],...
            [DATAFolders{k,j},'\AxialLinearFig\Trj']};
        
        for m=1:numCells
            if ismember(m,ExcludedCells)
                continue
            end
            if isfield(AxialMSD.AllTrajectoriesMSD,['Cell_',num2str(m)])
                
                fprintf(['Cell: ',num2str(m),'\n']);
                %% generate this cell fit figures
                
                eval(['MSD = AxialMSD.AllTrajectoriesMSD.Cell_',...
                    num2str(m),'(:,:,1);']);
                eval(['Trj = GeneralAnalysisResults.AllCellsData.Cell_',...
                    num2str(m),'.Trajectories;']);
                Trj = permute(Trj,[3,2,1]);
                
                % save figures
                for i=1:size(MSD,2)
                    %%%%%%%%%%%%%%%%%%%%% linear fit %%%%%%%%%%%%%%%%%%%%%%
                    Data=MSD(:,i);
                    CCCDO.FitMMSD(TransitionTime,Data,MaxT,Dimensionality,...
                        [CellTypeName{1,k},'_',PhaseNames{1,j},...
                        '_Cell_',num2str(m),'_Trj_',num2str(i)],SaveFolderes);
                    %%%%%%%%%%%%%%%% Trajectories %%%%%%%%%%%%%%%%%%%%%%%%%
                    time = [1:NumFrames].*0.1;
                    
                    % titleStr cell array with titles for the figure:
                    %          {1,1} figure window name 
                    %          {1,2} figure title 
                    %          {1,3} figure file name 
                    %          {1,4} figure file format
                    titleStr=cell(1,4);
                    titleStr{1,1} = [CellTypeName{1,k},' ',PhaseNames{1,j},...
                        ' Cell',num2str(m),' Trj',num2str(i)];
                    titleStr{1,2} = [CellTypeName{1,k},' ',PhaseNames{1,j},...
                        ' Cell',num2str(m),' Trj',num2str(i)];
                    titleStr{1,3} = [SaveFolderes{1,4},'\',...
                        CellTypeName{1,k},'_',PhaseNames{1,j},...
                        '_Cell_',num2str(m),'_Trj_',num2str(i)];
                    titleStr{1,4} = 'bmp';
                    coordinates = Trj(:,:,i);                    
                    CCCDO.TrjectoryColorFigFull(time,coordinates,titleStr);
                    clear coordinates
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                end
                close all;
                
            end
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
