%% RunMode Function: SingleCellAnalysis
% This function run MSD analysis for single cell 
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       ExperimentFolder:       Directory of the current experiment
%       NumFrames:              Number of frames (timepoints)
%       ThisCell:               cell number
%       CellType:               cell line MEF3T3 or MEFLmnaKO
%       MinLength:              trajerctory length cutoff
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       AnalysisResults:    struct with fields
%           .TauVec         time vector with units [sec]
%           .MSD            Mean Squere Displacment vector with unit: [um^2] 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function AnalysisResults = SingleCellAnalysis...
(ExperimentFolder,NumFrames,ThisCell,CellType,MinLength)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%import data 
% if exist mat file with this cell data, the function will load it
filename=['Cell_',num2str(ThisCell),'_LinkData.mat'];
if exist(filename,'file')
    load(filename);
    eval(['LinkData=Cell_',num2str(ThisCell),';']);
else
    LinkData = CCCDO.ArrengeAllData...
        (ExperimentFolder,NumFrames,ThisCell,MinLength);
end

% prepare data for MSD plot
MSD=LinkData.MSD;
Data=MSD(:,:,1);
TauVec=[1:NumFrames].*0.1;
%       FigParameter    struct with at least three fields: 
%          .CellType    cell line MEF3T3 or MEFLmnaKO
%          .CurrentCell cell number
%          .FigIdx      logical index: 1- drow figure, and 0- Figure not
%                       requiered
FigParameter=struct();
FigParameter.CellType=CellType;
FigParameter.CurrentCell=ThisCell;
FigParameter.FigIdx=1;
FigParameter.EdgeTerms=[70,NumFrames/2];

% MSD analysis plot
CCCDO.MSDCurvePlot(FigParameter,TauVec,Data);
close all

% save results 
AnalysisResults=struct();
AnalysisResults.MSD=MSD;
AnalysisResults.TauVec=TauVec;

save 'ResultsAnalysis.mat' 'AnalysisResults'

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
