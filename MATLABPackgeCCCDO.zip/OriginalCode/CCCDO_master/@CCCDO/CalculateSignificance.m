%% QC Function: CalculateSignificance
% This function calculates distribution p value with confidence of
% 0.2,0.05,0.01 and 0.001
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       Dimensionality:     type of analysis:
%                           1- Axial(Z), 2- Lateral(xy),3- 3D analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       AlphaPvalueMat:     Anomalous exponent. cell 1 by number of cell
%                           lines. each cell is a matrix with p values
%                           while (:,:,1) <0.05, (:,:,2) <0.01,
%                           and (:,:,3)<0.001
%       DPvalueMat:         Anomalous exponent. cell 1 by number of cell
%                           lines. each cell is a matrix with p values
%                           while (:,:,1) <0.1, (:,:,2) <0.01,
%                           and (:,:,3)<0.001
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function [AlphaPvalueMat,DPvalueMat,varargout] = ...
    CalculateSignificance(Dimensionality)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% import user parameters
idx={0,5};
[ExperimentFolder,~,~,~,~,~,~,PhaseNames,CellTypeName,~] = ...
    UserParameter(idx);
% load data
switch Dimensionality
    
    case 1
        DataFolder = [ExperimentFolder,'\EnsembleAnalysis\Axial'];
        fprintf('calculate confidence values of Axial analysis\n');
    case 2
        DataFolder = [ExperimentFolder,'\EnsembleAnalysis\Lateral'];
        fprintf('calculate confidence values of Lateral analysis\n');
    case 3
        DataFolder = [ExperimentFolder,'\EnsembleAnalysis\Full'];
        fprintf('calculate confidence values of 3D analysis\n');
end

load([DataFolder,'\Results.mat'],'Results');
% re-arrange data
Data = cell(numel(CellTypeName),numel(PhaseNames));
for i=1:2
    for j=1:5
        eval(['Data{i,j} = Results.GeneralCoVec.',...
            PhaseNames{1,j},'.',CellTypeName{1,i},';']);
    end
end

%% two sample t -test for alpha exponent distribution
Alpha = [0.2,0.05,0.01,0.001];
AlphaPvalueMat = cell(1,numel(CellTypeName));
DPvalueMat = cell(1,numel(CellTypeName));

for n=1:numel(CellTypeName)
    AlphaPvalueMat{1,n} = ...
        nan(numel(PhaseNames),numel(PhaseNames),length(Alpha));
    DPvalueMat{1,n} = ...
        nan(numel(PhaseNames),numel(PhaseNames),length(Alpha));
    for k=1:length(Alpha)
        for i=1:numel(PhaseNames)
            for j=1:numel(PhaseNames)
                %%%%%%%%%%%%%%%%%%%%%%%% alpha %%%%%%%%%%%%%%%%%%%%%%%%%%%%
                [h1,p1] = ...
                    ttest2(Data{n,i}(:,1,2),Data{n,j}(:,1,2),...
                    'Alpha',Alpha(k),'Vartype','unequal');
                if h1~=0
                    AlphaPvalueMat{1,n}(i,j,k) = h1*p1;
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%%%%%%%%%%%%%%% D %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                [h2,p2] = ...
                    ttest2(Data{n,i}(:,2,2),Data{n,j}(:,2,2),...
                    'Alpha',Alpha(k),'Vartype','unequal');
                
                if h2~=0
                    DPvalueMat{1,n}(i,j,k) = h2*p2;
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            end
        end
    end
end
save([DataFolder,'\PvalueMat.mat'],'AlphaPvalueMat','DPvalueMat');
varargout{1} = [];
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
