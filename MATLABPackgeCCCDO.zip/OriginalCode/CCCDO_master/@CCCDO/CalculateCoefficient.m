%% Pipeline Function: CalculateCoefficient
% This function calculates separately the anomalous exponent and diffusion
% coefficient for three behavior regimes: glass-like, rubber-like,
% liquid-like
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       tauCut:         transition times (in frames).  
%                       row- cell cycle phases
%                       1st column: glass-rubber transition 
%                       2nd column: rubber-liquid transition 
%                       (:,:,1) MEF3T3 and (:,:,2) MEFLmnaKO
%       MSD:            struct with field equal to PhasesName; each one of
%                       them is struct with field {'MEF3T3','MEFLmnaKO'}
%                       with MSD vectors of all trajectories in this phase
%       PhasesName:     cell array with phases names {'G0','S','G2','LateG2','UT'}      
%       CellTypeName:   cell array with cell lines names {'MEF3T3','MEFLmnaKO'}
%       FigParameter:   struct with parameters for figure drawing
%       FolderName:     folder path to save the figures and results
%       TauVec:         Time vector in sec
%       MinLength:      minimal length of trajectory    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       CoefficientVec:     struct with field equal to PhasesName; each one
%                           of them is struct with fields {'MEF3T3','MEFLmnaKO'} 
%                           double matrix {telomere#,[alpha, D, GOF],3} while:
%                           row- number of telomeres
%                           column 1: anomalous exponent
%                           column 2: diffusion coefficient
%                           column 3: goodness of the fit
%                           (:,:,1) glass-like   tau<Tg
%                           (:,:,2) rubber-like  Tg<tau<Tl
%                           (:,:,3) liquid-like  tau>Tl
%       ParameterMat:       matrix of parameters. 
%                           struct with field equal to PhasesName; each one
%                           of them is struct with fields {'MEF3T3','MEFLmnaKO'}
%                           while:
%                           rows (Mean, variance, skewness, kurtosis)
%                           column(Tau<Tg, Tg<tau<Tl, tau>Tl )
%                           (:,:,1) alpha exponent
%                           (:,:,2) D*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function [CoefficientVec,ParameterMat] = CalculateCoefficient ...
(tauCut,MSD,PhasesName,CellTypeName,FigParameter,FolderName,TauVec,MinLength)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define local parameter
ParMat=zeros(4,3,2);
Tmax=750;

for i=1:numel(PhasesName)
    for j=1:2
        Tg=floor(tauCut(i,1,j)./10);
        Tr=floor(tauCut(i,2,j)./10);
        if Tr<Tg
           Tg=Tr;
        end
        TauCutOff=[Tg,Tr];
        
        fprintf(['Fitting ',PhasesName{1,i},' ',...
            CellTypeName{1,j},'\n']);
        eval(['Data=MSD.',PhasesName{1,i},'.',...
            CellTypeName{1,j},'(:,:,1);']);
%         ExperimentTitle=['',CellTypeName{1,j},' ',PhasesName{1,i}];
        for k=1:3
            
            switch k
                case 1
                    FigParameter.EdgeTerms=[Tg*10,Tr*10];
                    temp = CCCDO.BiLinearFitPlot...
                        (FigParameter,TauVec,Data,MinLength);
                    tempCO = zeros(size(temp,1),size(temp,2),3);
                case 2
                    FigParameter.EdgeTerms=[(Tr-Tg)*5,Tr*10];
                    temp = CCCDO.BiLinearFitPlot...
                        (FigParameter,TauVec,Data,MinLength);
                case 3
                    FigParameter.EdgeTerms=[(Tr+2)*10,Tmax+MinLength];
                    temp = CCCDO.BiLinearFitPlot...
                        (FigParameter,TauVec,Data,MinLength);
            end
            tempCO(:,:,k)=temp(:,:,1);
            % generate parameter matrix
            % anomalous exponent (alpha)
            tempParameterMat(:,:,1) = ...
                [mean(temp(:,1,1)),mean(temp(:,1,2));...
                var(temp(:,1,1)),var(temp(:,1,2));....
                skewness(temp(:,1,1)),skewness(temp(:,1,2));....
                kurtosis(temp(:,1,1)),kurtosis(temp(:,1,2));];
            % diffusion coefficient (D*)
            tempParameterMat(:,:,2) = ...
                [mean(temp(:,2,1)),mean(temp(:,2,2));...
                var(temp(:,2,1)),var(temp(:,2,2));....
                skewness(temp(:,2,1)),skewness(temp(:,2,2));....
                kurtosis(temp(:,2,1)),kurtosis(temp(:,2,2));];
            
            ParMat(:,k,:)=tempParameterMat(:,1,:);

        end
        
        % save output
        eval(['CoefficientVec.',PhasesName{1,i},'.',CellTypeName{1,j},...
            '=tempCO;']);
        eval(['ParameterMat.',PhasesName{1,i},'.',CellTypeName{1,j},...
            '=ParMat;']);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
