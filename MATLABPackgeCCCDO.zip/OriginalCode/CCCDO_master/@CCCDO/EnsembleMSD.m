%% Run Mode Function: EnsembleMSD
% This function calculates anomalous exponent and diffusion coefficient.
% compare between cell cycle phase and between cell lines (MEF 3T3 and MEF
% LmnaKO)
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       ExperimentFolder:           path for load data cell array 2 by 5 
%       FolderName:                 path for saving the figures and results 
%       Dimensionality:             type of analysis: 
%                                   1- Axial(Z), 2- Lateral(xy),3- 3D
%                                   analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       Results:    		struct with fields: 
%           .GeneralCoVec:          struct with field equal to PhasesName;
%                                   each one of them is struct with fields
%                                   {'MEF3T3','MEFLmnaKO'}
%                                   double matrix {telomere#,[alpha,D,GOF],3}
%                                   while:  row- number of telomeres
%                                           column 1: anomalous exponent
%                                           column 2: diffusion coefficient
%                                           column 3: goodness of the fit
%                                           (:,:,1)    tau<Tr
%                                           (:,:,2)    tau>TL
%           .TransitionTime:        Transition time separate between short
%                                   times t<Tr and longer times t>TL; 
%                                   vector 5 by 2 by 2 while:
%                                   row- cell cycle phase
%                                   column- Tr,TL
%                                   (:,;,1)'MEF3T3',(:,;,2)'MEFLmnaKO'
%           . MSD:                  struct with field equal to PhasesName;
%                                   each one of them is struct with fields
%                                   {'MEF3T3','MEFLmnaKO'}
%                                   Double M by N by 5 while:
%                                   rows: time-points 
%                                   columns: trajectories 
%                                   (:,:,1) MSD values
%                                   (:,:,2) pairs count in each time point
%                                   (:,:,3) standard deviation
%                                   (:,:,4) t-test low value
%                                   (:,:,5) t-test high value
%           .MMSD:                  ensemble MSD vector; struct with field
%                                   equal to PhasesName;
%                                   each one of them is struct with fields
%                                   {'MEF3T3','MEFLmnaKO'}
%           .ParameterMat:          struct with field equal to PhasesName;
%                                   each one of them is struct with fields
%                                   {'MEF3T3','MEFLmnaKO'}
%                                   matrix of parameters. while:
%                                   rows (Mean, variance, skewness, kurtosis)
%                                   column(Tau<Tr,tau>TL ) 
%                                   (:,:,1) alpha exponent
%                                   (:,:,2) D*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function Results =...
EnsembleMSD(ExperimentFolder,FolderName,Dimensionality)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% define local parameters

PhasesName={'G0','S','G2','LateG2','UT'};
CellTypeName={'MEF3T3','MEFLmnaKO'};

MaxT= 300;


ParameterMat=struct();
%% import data
fprintf('import data\n');
cd(FolderName);
if exist(['',FolderName,'\MEF3T3_Data.mat'],'file')...
        && exist(['',FolderName,'\MEFLmnaKO_Data.mat'],'file')
    load('MEF3T3_Data.mat');
    load('MEFLmnaKO_Data.mat');
    fprintf('data imported \n');
else
    % one or all data files are not exist
    for j=1:2
        CellType = CellTypeName{1,j};
        if exist([FolderName,'\',CellType,'_Data.mat'],'file')
            load([FolderName,'\',CellType,'_Data.mat'],['',CellType]);
        else % 1st time: load and save data according to user dialog box
            for i=1:5
                % Lateral X,Y analysis
                if Dimensionality==2
                    File='LateralMSD.mat';
                    load([ExperimentFolder{j,i},'\Analysis\',File],...
                        'LateralMSD');
                    eval([PhasesName{1,i},'Data=LateralMSD;']);
                    
                % Axial Z analysis
                elseif Dimensionality==1
                    File='AxialMSD.mat';
                    load([ExperimentFolder{j,i},'\Analysis\',File],...
                        'AxialMSD');
                    eval([PhasesName{1,i},'Data=AxialMSD;']);
                    
                % Full (3D) analysis
                else
                    File='GeneralAnalysisResults.mat';
                    load([ExperimentFolder{j,i},'\Analysis\',File],...
                        'GeneralAnalysisResults');
                    eval([PhasesName{1,i},'Data=GeneralAnalysisResults;']);
                end
                
            end          
            % remove redandent parameteres
            if Dimensionality==2
                clear File Path LateralMSD
            elseif Dimensionality==1
                clear File Path AxialMSD
            else
                clear File Path GeneralAnalysisResults
            end
            
            % collect all data
            eval(['',CellType,'.G0Data = G0Data;']);
            eval(['',CellType,'.SData = SData;']);
            eval(['',CellType,'.G2Data = G2Data;']);
            eval(['',CellType,'.LateG2Data = LateG2Data;']);
            eval(['',CellType,'.UTData = UTData;']);
            save(['',CellType,'_Data.mat'],['',CellType]);
        end
    end
end

%% rearrange data
fprintf('rearrange data\n');
MSD = struct();
MMSD = struct();
GeneralCoVec = struct();
ParameterMat = struct();
TransitionTime=zeros(5,2,2);
for i=1:numel(PhasesName)
    for j=1:2
        % group MSD vectores
        eval(['MSD.',PhasesName{1,i},'.',CellTypeName{1,j},...
            '=',CellTypeName{1,j},'.',PhasesName{1,i},'Data.generalMSD;']);
        % group Ensemble MSD vectores
        eval(['MMSD.',PhasesName{1,i},'.',CellTypeName{1,j},...
            '=',CellTypeName{1,j},'.',PhasesName{1,i},'Data.MMSD;']);
        % group Coefficent  vectores
        eval(['GeneralCoVec.',PhasesName{1,i},'.',CellTypeName{1,j},...
            '=',CellTypeName{1,j},'.',PhasesName{1,i},'Data.GeneralCoVec;']);
        % group ParameterMat  vectores
        eval(['ParameterMat.',PhasesName{1,i},'.',CellTypeName{1,j},...
            '=',CellTypeName{1,j},'.',PhasesName{1,i},'Data.ParameterMat;']);
        % collect Transition times
        eval(['temp = ',CellTypeName{1,j},'.',...
            PhasesName{1,i},'Data.TransitionTime;']);
        TransitionTime(i,1,j)=temp(1);
        TransitionTime(i,2,j)=temp(2);
        
    end
end
%% save results
if exist([FolderName,'\Results.mat'],'file')
    load([FolderName,'\Results.mat'],'Results');
else
    Results=struct();
    Results.MSD=MSD;
    Results.MMSD=MMSD;
    Results.ParameterMat=ParameterMat;
    Results.TransitionTime=TransitionTime;
    Results.GeneralCoVec=GeneralCoVec;
    save([FolderName,'\Results.mat'],'Results');
end

%% Ensemble MSD analysis figures 
fprintf('generate figures \n');
%%%%%%%%%%%%%%%%% Mean Squered Displacement figures %%%%%%%%%%%%%%%%%%%%%%%
CCCDO.MMSDMain(FolderName,Results.MSD,Dimensionality,MaxT);

%%%%%%%%%%%%%%%%% violin anomalous exponent (alpha) %%%%%%%%%%%%%%%%%%%%%%%
% for MEF 3T3
CaseRun={1,1};
CCCDO.ViolinFig(FolderName,PhasesName,CellTypeName,...
    Results.GeneralCoVec,CaseRun,Dimensionality);

% for MEF LmnaKO
CaseRun={1,2};
CCCDO.ViolinFig(FolderName,PhasesName,CellTypeName,...
    Results.GeneralCoVec,CaseRun,Dimensionality);

% for Both 3T3 and LmnaKO
CaseRun={2,0};
CCCDO.ViolinFig(FolderName,PhasesName,CellTypeName,...
    Results.GeneralCoVec,CaseRun,Dimensionality);
%%%%%%%%%%%%%%%%%%%% violin Diffusion constant (D) %%%%%%%%%%%%%%%%%%%%%%%%
CaseRun={3,0};
CCCDO.ViolinFig(FolderName,PhasesName,CellTypeName,...
    Results.GeneralCoVec,CaseRun,Dimensionality);

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
