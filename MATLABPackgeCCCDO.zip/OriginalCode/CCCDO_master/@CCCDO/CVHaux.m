%% Auxiliary Function: CVHaux
% This function using Convex Hull to calculate the scanning volume of each
% trajectory until specific time (by default 25 s) , for one experiment.
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       T:              time in frame , to calculate the scanning volume.
%                       if is empty will by defined T=250;
%       numCells:       number of cells.
%       Data:           struct with fields name 'Cell_*', includes all
%                       cells data. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       CVH:            cell 1 by number of trajectories, includes the
%                       Convex Hull of each trajectory in separate cell.
%       VcH:            the volume of each trajectory. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function [CVH,VcH] = CVHaux(T,numCells,Data,Dimensionality)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% single trjectory
m=0;
VcH = [];
for CellNum = 1:numCells
    
    if ~isfield(Data,['Cell_',num2str(CellNum)])
        continue
    else
        eval(['tempA = Data.Cell_',num2str(CellNum),'.Trajectories;']);
        n=1;
        
        % CVH = cell(1,size(tempA,1));
        VcH = vertcat(VcH,zeros(size(tempA,1),1));
        for TrjNum=1:size(tempA,1)
            temp = tempA(TrjNum,:,:);
            temp = permute(temp,[3 2 1]);
            temp = rmoutliers(temp,'quartiles');
            % according to Dimensionality
            tempB = temp;
%             switch Dimensionality
%                 case 1
%                     tempB = temp(:,2:3);
%                 case 2
%                     tempB = temp(:,1:2);
%                 case 3
%                     tempB = temp(:,1:3);
%             end
            
%             tempB = rmoutliers(temp);
            tempB(isnan(tempB(:,1)),:) = [];
            if isempty(T)
                [CVH{1,n+m},VcH(n+m)] =...
                    convhull(tempB(:,1),tempB(:,2),tempB(:,3));
                CVH{2,n+m} = temp;
                n = n+1;
            elseif length(tempB)>=T
                switch Dimensionality
                    case 1
                        [CVH{1,n+m},VcH(n+m)] = ...
                            convhull(tempB(1:T,1),tempB(1:T,3));
                    case 2
                        [CVH{1,n+m},VcH(n+m)] =...
                            convhull(tempB(1:T,1),tempB(1:T,2));
                    case 3
                        [CVH{1,n+m},VcH(n+m)] =...
                            convhull(tempB(1:T,1),tempB(1:T,2),tempB(1:T,3));
                end
                CVH{2,n+m} = temp;
                n = n+1;
                
            end
            clear tempB
        end
        VcH(VcH==0)=[];
        m = m + n;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
