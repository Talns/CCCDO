%% Auxilary Function: ArrengeAffineMat
% This function arrange the affine matrixes that have been used to correct
% nucleus drift form CSV file. 
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       ExperimentFolder:       Directory of the current experiment
%       NumFrames:              Number of frames (timepoints)
%       ThisCell:               cell number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       AffineMat:    cell array 1 by number of frame. each cell contains
%                     affine matrix of the relative frame
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function AffineMat = ArrengeAffineMat...
(ExperimentFolder,NumFrames,ThisCell)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define local parameters
ExperimentName=split(ExperimentFolder,'\');
ExperimentName=ExperimentName{end};
DataPath=['',ExperimentFolder,'\Analysis\Cell_',num2str(ThisCell)];

%read csv file
Temp1= xlsread([DataPath,'\',...
    ['',ExperimentName,'_Cell_',num2str(ThisCell),'_homographies.csv']]);

AffineMat=cell(1,NumFrames);
% buld affine matrix
for i=2:size(Temp1,1)
    temp=Temp1(i,2:7);
    temp=vertcat(temp(1,1:3),temp(1,4:6));
    temp=vertcat(temp,[0 0 1]);
    temp=temp';
    AffineMat{1,i-1}=temp;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
