%% Auxilairy Function: ArrengeTrajectories
% This function generate struct from all CSV file after linking analysis
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       ExperimentFolder:       Directory of the current experiment
%       NumFrames:              Number of frames (timepoints)
%       ThisCell:               cell number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       Trajectories:           double num of trjectories by 4 by num of
%                               frames
%                               row- trjectories
%                               columns- [x,y,z,amp] XYZ units:um ,
%                                        amp:0-800
%                               (:,:,3)- timepoints(frames)
%       TrjLength:              vector with length of not nan data for each
%                               trjectory
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%
%## activate when finish ##%
function [Trajectories,TrjLength] = ArrengeTrajectories...
    (ExperimentFolder,NumFrames,ThisCell,MinLength)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define local parameters
ExperimentName=split(ExperimentFolder,'\');
ExperimentName=ExperimentName{end};
DataPath=['',ExperimentFolder,'\Analysis\Cell_',num2str(ThisCell)];

%% trajectories Data
%read csv file
fprintf('read csv file\n');
Temp1=xlsread([DataPath,'\',...
    ['',ExperimentName,'_Cell_',num2str(ThisCell),'_trajectories.csv']]);
% number of trajectories
NumTrjec=max(Temp1(:,2));
Trajectories=nan(NumTrjec,4,NumFrames);
% enter data to matrix
fprintf('Build trajectories vector\n');
for i=1:NumTrjec
    Thistrj=Temp1(Temp1(:,2)==i,:);
    for j=1:NumFrames
        if ismember(j-1,Thistrj(:,3))
            Trajectories(i,1,j)=Thistrj(Thistrj(:,3)==j-1,4);
            Trajectories(i,2,j)=Thistrj(Thistrj(:,3)==j-1,5);
            Trajectories(i,3,j)=Thistrj(Thistrj(:,3)==j-1,6);
            Trajectories(i,4,j)=Thistrj(Thistrj(:,3)==j-1,7);
        end
    end
end
% nm to um
Trajectories(:,1:3,:)=Trajectories(:,1:3,:)./1000;
% calculate trajectory length
TrjLength=zeros(NumTrjec,1);
for i=1:NumTrjec
    TrjLength(i)=length(find(~isnan(Trajectories(i,1,:))));
end
% apply filter 
Trajectories=Trajectories(TrjLength>=MinLength,:,:);
% update trajectory length
clear TrjLength
TrjLength=zeros(size(Trajectories,1),1);
for i=1:size(Trajectories,1)
    TrjLength(i)=length(find(~isnan(Trajectories(i,1,:))));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
