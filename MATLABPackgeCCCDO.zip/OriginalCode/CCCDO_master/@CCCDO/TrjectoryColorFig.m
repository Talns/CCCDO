%% Figure Function: TrjectoryColorFig
% this function generate trajectory coordinat figure when the time is 
% coded to color, using smooth filter.   
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       time:           vector of time 
%       coordinates:    vector [x,y,z]
%       titleStr        cell array with titles for the figure:
%                       {1,1} figure window name 
%                       {1,2} figure title 
%                       {1,3} figure file name 
%                       {1,4} figure file format
%       varargin:       if axis limit is specified, cell 1 by 3, each one
%                       is a vector [min, max]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% no output for this function %%%%%%%%%%%%%%%%%%%%%%%       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function TrjectoryColorFig(time,coordinates,titleStr,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('name',['',titleStr{1,1}],'NumberTitle','off');
% encode time to colormap
cm = jet(length(time));
colormap(cm);
color_scale = linspace(0,size(cm,1),numel(time));
% plot 3D phase plane

x=coordinates(:,1);y=coordinates(:,2);z=coordinates(:,3);
x = smooth(x,12,'rloess',8);
y = smooth(y,12,'rloess',8);
z = smooth(z,12,'rloess',8);
surf([x,x],[y,y],[z,z],[color_scale',color_scale'],...
    'EdgeColor','flat', 'FaceColor','none');

% specify colorbar proporties
c = colorbar;
c.Label.FontSize=12;
c.Location='SouthOutside';

% limits
Limits=varargin{1};
xlim([Limits{1,1}(1)-0.1,Limits{1,1}(2)+0.1]);
ylim([Limits{1,2}(1)-0.1,Limits{1,2}(2)+0.1]);
zlim([Limits{1,3}(1)-0.1,Limits{1,3}(2)+0.1]);
% axis equal
ylabel('Y [\mu m]');
xlabel('X [\mu m]');
zlabel('Z [\mu m]')
title(['',titleStr{1,2}]);
grid on
box on
saveas(gcf,['',titleStr{1,3}],['',titleStr{1,4}]);

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end