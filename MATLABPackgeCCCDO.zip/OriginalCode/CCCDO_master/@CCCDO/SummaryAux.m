%% Auxiliary Function: SummaryAux
% This function arrange data for summary run mode  
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       DataFolders:                    Directory to load data.
%       TimeAve:                        specific time in sec for calculate 
%                                       the constraining volume. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       Results:                        struct with two fields
%           .ConstrainingRadius:        struct with 3 fields:
%                                       {'Full','Lateral','Axial'}; each
%                                       field is a struct with 5 field,
%                                       with phase names. while each one is
%                                       struct with
%                                       fields{'MEF3T3','MEFLmnaKO'}. each
%                                       one is vector of the constraining
%                                       vector at specific time
%           .MeanConstrainingRadius:    vector 4 by 5 by 3 while:
%                                       row 1,2 are the mean value
%                                       calculated from the vector
%                                       ConstrainingRadius and row 3,4 is
%                                       values calculated from the ensemble
%                                       MSD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function Results = SummaryAux(DataFolders,TimeAve)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define parameters
PhasesName={'G0','S','G2','LateG2','UT'};
CellTypeName={'MEF3T3','MEFLmnaKO'};
% cell arrays for saving data
DataMSD=cell(1,3);
DataMMSD=cell(1,3);
% Constraining volume vectors 
ConstrainingRadius = struct();
MeanConstrainingRadius = zeros(4,5,3);

% time indx
T=TimeAve*10;
%% collect raw data
fprintf('collect raw data\n');
for i=1:3
    load(['',DataFolders{1,i},'\Results.mat'],'Results');
    DataMSD{1,i} = Results.MSD;
    DataMMSD{1,i} = Results.MMSD;
    clear Results
end
clear i 
%% rearrange data
AnalysisNames = {'Full','Lateral','Axial'};
for k=1:3
    for i=1:5
        for j=1:2
            % calculate constraining volume vector
            eval(['ConstrainingRadius.',AnalysisNames{1,k},'.',...
                PhasesName{1,i},'.',CellTypeName{1,j},...
                ' = sqrt(DataMSD{1, k}.',...
                PhasesName{1,i},'.',CellTypeName{1,j},'(T,:,1));']);
            % calculate mean constraining volume from ensemble MSD vector
            eval(['MeanConstrainingRadius(j+2,i,k) = sqrt(DataMMSD{1, k}.',...
                PhasesName{1,i},'.',CellTypeName{1,j},'(T,:,1));']);
            % calculate real mean constraining volume from vector
            eval(['temp = ConstrainingRadius.',AnalysisNames{1,k},...
                '.',PhasesName{1,i},'.',CellTypeName{1,j},';']);
            MeanConstrainingRadius(j,i,k) = ...
                mean(temp,2,'omitnan');
            clear temp
        end
    end
end

Results.ConstrainingRadius = ConstrainingRadius;
Results.MeanConstrainingRadius = MeanConstrainingRadius;
save 'Results.mat' Results
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end