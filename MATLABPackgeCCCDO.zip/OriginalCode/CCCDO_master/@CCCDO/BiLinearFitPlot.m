%% Pipeline Function: BiLinearFitPlot
% generate linear fit: log10(MSD/tau)=(alpha-1)log10(tau)+log10(D) for
% before and after specified time. this function is used to find the
% transition times (Tr and TL)

%% function parameter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       FigParameter    struct with at least the following fields:
%          .CellType    cell line MEF3T3 or MEFLmnaKO
%          .CurrentCell cell number
%          .FigIdx      logical index: 1- draw figure, and 0- Figure not
%                       required
%          .EdgeTerms   vector with two entries: first is a transition time
%                       Tr or TL, and the second is the maximal time
%                       interval to be considered for coefficient extraction  
%       TauVec          time vector with units [sec]
%       Data             Mean Square Displacement vector with unit: [um^2]
%                       double {time, Telomere#}
%       MinLength:      minimal number of pairs\trajectory length
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       CoefficientVec  double matrix {telomere#,[alpha,D,GOF],2} while:
%                       row- number of telomeres
%                       column 1: anomalous exponent
%                       column 2: diffusion coefficient
%                       column 3: goodness of the fit
%                       (:,:,1) before tau=7sec
%                       (:,:,2) after  tau=7sec
%% script starts here %%
function CoefficientVec=BiLinearFitPlot(FigParameter,TauVec,Data,MinLength)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
warning('off')
% make folder to save files
if FigParameter.FigIdx
    % save current folder path
    currentFolder = pwd;
    old=currentFolder;
    % make new folder to save figures
    mkdir(currentFolder,['',FigParameter.CellType,...
        '_',num2str(FigParameter.CurrentCell),'_BiLinearFit_Figures']);
    % goto new folder
    cd([currentFolder,'\\','',FigParameter.CellType,...
        '_',num2str(FigParameter.CurrentCell),'_BiLinearFit_Figures']);
end
% define parameter
NumOfTelomeres=size(Data,2);  % number of telomeres
CoefficientVec=zeros(NumOfTelomeres,3,2); % save memory
for j=1:NumOfTelomeres % for each telomere
    %     if ismember(j,ExcludedTrj)
    %         continue
    %     end
    for i=1:2 % bi-linear fit before and after tau=7sec
        %% fit linear curve to data
        x=log10(TauVec');
        y=log10((Data(:,j)./TauVec'));
        % Prepare data inputs for curve fitting.
        [xData, yData] = prepareCurveData( x, y );
        % ignore empty trajectories
        if isempty(xData)|| isempty(yData) ||...
                length(xData)<= (MinLength-70) ||length(yData)<=(MinLength-70)
            continue
        end
        % define indexs to be excluded from fit curve
        switch i
            case 1 % before tau=7sec
                LastIndex=min((length(TauVec)-1),length(xData));
                if LastIndex<=FigParameter.EdgeTerms(1)
                    ind_vec = [1 LastIndex];
                else
                    ind_vec=[1 FigParameter.EdgeTerms(1):LastIndex];
                end
                
                TimeZone='before 7sec';
                
            case 2 % after tau=7sec
                LastIndex=min((length(TauVec)-1),length(xData));
                if LastIndex<=FigParameter.EdgeTerms(2)
                    ind_vec = [];
                else
                    ind_vec=[1:FigParameter.EdgeTerms(1)...
                        FigParameter.EdgeTerms(2):LastIndex];
                end
                TimeZone='after 7sec';
        end
        
        
        % Set up fittype and options.
        ft = fittype( 'poly1' );
        
        excludedPoints = excludedata( xData, yData, 'Indices', ind_vec );
        opts = fitoptions( 'Method', 'LinearLeastSquares' );
        opts.Exclude = excludedPoints;
        
        % Fit model to data.
        [fitresult, gof] = fit( xData, yData, ft, opts );
        % extract coefficients
        MyCoeffs = coeffvalues(fitresult);
        % save anomulous exponent (alpha)
        CoefficientVec(j,1,i)= MyCoeffs(1)+1;
        % save diffusion coefficient (D_alpha)
        CoefficientVec(j,2,i) = (10^MyCoeffs(2));
        % save goodness of fit
        CoefficientVec(j,3,i)=gof.rsquare;
        
        %% generate figure
        if FigParameter.FigIdx
            figure('name',['',FigParameter.CellType,'_',...
                num2str(FigParameter.CurrentCell),...
                'telomere_',num2str(j),' ',TimeZone],...
                'NumberTitle','off');
            plot(fitresult,'m',xData(2:end),yData(2:end),...
                '*b',excludedPoints(2:end),'+g');
            legend('included points', 'Excluded points',...
                'fitted line', 'Location', 'NorthEast' );
            xlabel ('log10(time) [sec]');
            ylabel ('log10(MSD/time) [\mu m^2/sec]');
            ylim([-5.5 2.5]);
            title(['',FigParameter.CellType,' ',...
                num2str(FigParameter.CurrentCell),...
                ' telomere ',num2str(j),' ',TimeZone,...
                ' r^2=',num2str(gof.rsquare,'%.2f')]);
            saveas(gcf,['',FigParameter.CellType,' ',...
                num2str(FigParameter.CurrentCell),...
                ' telomere ',num2str(j),' ',TimeZone],'bmp');
        end
    end
end
CoefficientVec(CoefficientVec<=0)=0; % remove negative values
if FigParameter.FigIdx;cd(old);end

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
