%% Figure Function: MeanMSDFig
% This function generates different types of Ensemble MSD curves.
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       PhasesName:     cell array with phases names
%                       {'G0','S','G2','LateG2','UT'}
%       CellTypeName:   cell array with cell lines names
%                       {'MEF3T3','MEFLmnaKO'}
%       MSD:            struct with field equal to PhasesName; each one of
%                       them is struct with field {'MEF3T3','MEFLmnaKO'}
%                       with MSD vectors of all trajectories in this phase
%       idx:            cell array 1 by 3:
%                       {1,1} cell line: 1-'MEF3T3' or 2-'MEFLmnaKO'
%                       {1,2} case index: 0- all phase without area std
%                                         1- single phase with area std
%                       {1,3} phase index 1-5 as in PhasesName
%                             0- each phase in separate subplot
%       Dimensionality:     type of analysis: 
%                               1- Axial(Z), 2- Lateral(xy),3- 3D analysis
%       MaxT:              Last frame to be included for MSD calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:           no output for this function  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function MeanMSDFig(PhasesName,CellTypeName,MSD,idx,Dimensionality,MaxT)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% local parameter
if Dimensionality==1
    limits=[-3.5,0,-1,2,MaxT];
else
    limits=[-3.5,-1,-1,2,MaxT];
end
IntervalTime=0.1;
colornames={'b','g','m','r','k'};
%% read index information
switch idx{1,2}
    case 0
        RunType=1;
    case 1
        switch idx{1,3}
            case 0
                RunType=2;
            otherwise
                
                if ismember(idx{1,3},[1:5])
                    RunType=3;
                else
                    errordlg('idx{1,3} must be index from [0,1,2,3,4,5]',...
                        'invalid index');
                    return
                end
        end
        
    otherwise
        errordlg('idx{1,1} must be "0" or "1" ','invalid index');
        return
        
end
%% collect data
for i=1:numel(PhasesName)
    for j=1:2
        
        eval(['Data{j,i} = MSD.',PhasesName{1,i},'.',CellTypeName{1,j},';']);
    end
end
%% generate figure
j=idx{1,1};
switch RunType
    case 1
        figure('name','MMSD','NumberTitle','off');
        
        for i=1:numel(PhasesName)
            MMSD=mean(Data{j,i}(:,:,1),2,'omitnan');
            tau=(1:length(MMSD))'.*IntervalTime;
            x=log10(tau(2:limits(5)));
            y=log10(MMSD(2:limits(5))./tau(2:limits(5)));
            plot(x,y,colornames{1,i});
            ylim([limits(1),limits(2)]);
            hold on;    
        end
        xlim([limits(3),limits(4)]);
        xticklabels({'10^-^1','10^-^0^.^5','10^0','10^0^.^5',...
            '10^1','10^1^.^5','10^2'});
        if Dimensionality==1
            yticklabels({'','10^-^3','10^-^2^.^5','10^-^2','10^-^1^.^5',...
                '10^-^1','10^-^0^.^5','10^-^0'});
        else
            yticklabels({'','10^-^3','10^-^2^.^5','10^-^2',...
                '10^-^1^.^5','10^-^1'});
        end
        ax = gca;
        ax.FontSize = 18;
        legend(PhasesName{:});
        title(CellTypeName{1,j},'fontsize',18);
        ylabel('<r^2>/\tau   [\mu m^2/sec]','fontsize',16);
        xlabel('\tau [sec]','fontsize',16);
        set(gcf,'position',[580 333 971 645]);
        box off
        saveas(gcf,['MMSD ',CellTypeName{1,j}],'bmp');
    case 2
        figure('name','MMSD','NumberTitle','off');
        for i=1:5
            subplot(2,3,i);
            MMSD=mean(Data{j,i}(:,:,1),2,'omitnan');
            tau=(1:length(MMSD))'.*IntervalTime;
            H=mean(Data{j,i}(:,:,5),2,'omitnan');
            yh=log10(H(2:limits(5))./tau(2:limits(5)));
            L=mean(Data{j,i}(:,:,4),2,'omitnan');
            yl=log10(L(2:limits(5))./tau(2:limits(5)));
            tau=(1:length(MMSD))'.*IntervalTime;
            x=log10(tau(2:limits(5)));
            y=log10(MMSD(2:limits(5))./tau(2:limits(5)));
            plot(x,y,colornames{1,i});
            hold on;
            area(x,yl,'facecolor',colornames{1,i},'facealpha',0.15,'linestyle','none');
            area(x,yh,'facecolor','w','linestyle','none');
            ylim([limits(1),limits(2)]);
            xlim([limits(3),limits(4)]);
            title([CellTypeName{1,j},' ',PhasesName{1,i}]);
            ylabel('<r^2>/\tau   [\mu m^2/sec]','fontsize',14);
            xlabel('\tau [sec]','fontsize',14); 
            ax = gca;
            ax.FontSize = 18;
        end
        box off
        set(gcf,'position',[440 186 976 770]);
        saveas(gcf,['MMSD all ',CellTypeName{1,j}],'bmp');
    case 3
        figure('name','MMSD','NumberTitle','off');
        i=idx{1,3};
        MMSD=mean(Data{j,i}(:,:,1),2,'omitnan');
        tau=(1:length(MMSD))'.*IntervalTime;
        H=mean(Data{j,i}(:,:,5),2,'omitnan');
        yh=log10(H(2:limits(5))./tau(2:limits(5)));
        L=mean(Data{j,i}(:,:,4),2,'omitnan');
        yl=log10(L(2:limits(5))./tau(2:limits(5)));
        tau=(1:length(MMSD))'.*IntervalTime;
        x=log10(tau(2:limits(5)));
        y=log10(MMSD(2:limits(5))./tau(2:limits(5)));
        plot(x,y,colornames{1,i});
        hold on;
        area(x,yl,'facecolor',colornames{1,i},'facealpha',0.15,'linestyle','none');
        area(x,yh,'facecolor','w','linestyle','none');
        ylim([limits(1),limits(2)]);
        xticklabels({'10^-^1','10^-^0^.^5','10^0','10^0^.^5',...
            '10^1','10^1^.^5','10^2'});
        if Dimensionality==1
            yticklabels({'','10^-^3','10^-^2^.^5','10^-^2','10^-^1^.^5',...
                '10^-^1','10^-^0^.^5','10^-^0'});
        else
            yticklabels({'','10^-^3','10^-^2^.^5','10^-^2',...
                '10^-^1^.^5','10^-^1'});
        end
        box off
        xlim([limits(3),limits(4)]);
        ax = gca;
        ax.FontSize = 18;
        title([CellTypeName{1,j},' ',PhasesName{1,i}]);
        ylabel('<r^2>/\tau   [\mu m^2/sec]','fontsize',14);
        xlabel('\tau [sec]','fontsize',14);
        set(gcf,'position',[580 398 600 580]);
        saveas(gcf,['MMSD ',CellTypeName{1,j},' ',PhasesName{1,i}],'bmp');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
