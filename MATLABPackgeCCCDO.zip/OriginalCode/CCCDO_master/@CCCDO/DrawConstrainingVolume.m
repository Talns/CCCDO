%% Figure Function: DrawConstrainingVolume
% This function draws Constraining Volume
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       MeanConstrainingRadius:      vector 4 by 5 by 3 while:
%                                    row 1,2 are the mean value calculated
%                                    from the vector ConstrainingRadius and
%                                    row 3,4 is values calculated from the
%                                    ensemble MSD
%       varargin:                    index; 1- combine xy and Z
%                                    2- xy data only. 3- 3D data only
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:                       no output for this function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function DrawConstrainingVolume(MeanConstrainingRadius,varargin)

%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define parameters
% phase and cell line names
PhasesName={'G0','S','G2','LateG2','UT'};
CellTypeName={'MEF3T3','MEFLmnaKO'};
n=varargin{1};
Data=MeanConstrainingRadius;
Names={'ellipsoid3D','Sphere2D','Sphere3D','SphereZ'};
%% generate figure

for j=1:2
    figure('name',[CellTypeName{1,j},' ',...
        Names{1,n}],'NumberTitle','off');
    for i=1:4
        subplot(1,4,i)
        
        switch n
            case 1
                [x,y,z] = ...
                    ellipsoid(0,0,0,Data(j+2,i,2)/2,Data(j+2,i,2)/2,...
                    Data(j+2,i,3)/2,50);
                L=([-0.275 0.275].*j);
                
            case 2
                [x,y,z] = ...
                    ellipsoid(0,0,0,Data(j+2,i,2)/2,Data(j+2,i,2)/2,...
                    Data(j+2,i,2)/2,50);
               L=([-0.275 0.275].*j);
            case 3
                [x,y,z] = ...
                    ellipsoid(0,0,0,Data(j+2,i,1)/2,Data(j+2,i,1)/2,...
                    Data(j+2,i,1)/2,50);
                L=([-0.15 0.15].*j);
                
            case 4
                [x,y,z] = ...
                    ellipsoid(0,0,0,Data(j+2,i,3)/2,Data(j+2,i,3)/2,...
                    Data(j+2,i,3)/2,50);
                L=([-0.25 0.25]).*j;
                
        end
        
        % L=([-0.25 0.25].*j);
        
        C={[0,0,1],[0,1,0],[1,0,1],[1,0,0],[0,0,0]};
        CO(:,:,1) =ones(length(x)).*C{1,i}(1);
        CO(:,:,2) =ones(length(x)).*C{1,i}(2);
        CO(:,:,3) =ones(length(x)).*C{1,i}(3);
        surf(x, y, z,CO);
        % configure axises
        axis equal
        xlim(L);
        ylim(L);
        zlim(L);
        ax = gca;
        ax.FontSize = 16;
        xlabel('X[\mu m]','fontsize',16);
        ylabel('Y[\mu m]','fontsize',16);
        zlabel('Z[\mu m]','fontsize',16);
        title(PhasesName{1,i});
    end
    set(gcf,'position',[114 190 1742 788]);
    saveas(gcf,['',CellTypeName{1,j},' ',Names{1,n}],'bmp');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
