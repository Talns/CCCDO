%% Figure Function: ViolinCV
% This function generate violin plot three types of constraining volume: 
% ellipsoid combines lateral and axial radiuses, V= (4/3)pi*(Rxy^2)*(Rz)
% spear base on lateral only information, V= (4/3)pi*(Rxy^3) 
% spear base on Axial only information, V= (4/3)pi*(Rz^3) 
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       idx:        task indexes; {1,1} type of figure {1,2} cell line
%       Data:       struct with 3 fields: {'Full','Lateral','Axial'};
%                   each field is a struct with 5 field, with phase names.
%                   while each one is struct with fields
%                   {'MEF3T3','MEFLmnaKO'}. each one is vector 
%                   of the constraining vector at specific time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:       no output for this function. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function ViolinCV(Data,idx)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define local parameters
colornames={'b','g','m','r','k'};
FigureType={'ellipsoid3D','Lateral','Axial'};
PhasesName={'G0','S','G2','LateG2','UT'};
CellTypeName={'MEF3T3','MEFLmnaKO'};
%% generate figure
FigureName=['',CellTypeName{1,idx{1,2}},' ',FigureType{1,idx{1,1}}];
figure('name',FigureName,'NumberTitle','off');
Y=cell(1,5);
for i=1:5 % collect each phase data
    
    eval(['X = Data.Lateral.',PhasesName{1,i},...
        '.',CellTypeName{1,idx{1,2}},';']);
    eval(['Z = Data.Axial.',PhasesName{1,i},...
        '.',CellTypeName{1,idx{1,2}},';']);
    switch idx{1,1}
        case 1
            % ellipsoid volume
            X=0.5.*X;
            Z=0.5.*Z;
            Y{1,i} = log10((4.*pi./3).*(X.^2).*Z);
        case 2
            % spear volume
            X=0.5.*X;
            Y{1,i} = log10((4.*pi./3).*(X.^3));
        case 3
            % spear volume
            Z=0.5.*Z;
            Y{1,i} = log10((4.*pi./3).*(Z.^3));
            
    end
    
    fprintf(['V = ',num2str(nanmean(Y{1,i}),'%.2e'),'\n']);
end

[h,L,MX,MED,bw] = CCCDO.violin(Y,colornames,'facealpha',0.25);
xticklabels(PhasesName);
ylabel('V_c [\mu m^3]','fontsize',16);
title(['constraining volume ',CellTypeName{1,idx{1,2}},...
    ' ',FigureType{1,idx{1,1}}]);

fprintf(['',FigureName,' Kernel bandwidth: ',...
    num2str(max(bw),'%.e'),'\n']);
ax = gca;
ax.FontSize = 18;
ylim([-4 2]);
box off
yticklabels({'10^-^4','10^-^3','10^-^2','10^-^1',...
    '10^0','10^1','10^2'});
set(gcf,'position',[453 229 1039 628]);
saveas(gcf,['',CellTypeName{1,idx{1,2}},...
    '_constraining_volume_',FigureType{1,idx{1,1}}],'bmp');

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
