%% Auxiliary Function: GenerateHistAuxParameter
% arrange parameters according to specified pipeline stage (Client) 
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Client:            index define which case to execute;
%                       1: Raw coordinate analysis;
%                       2: QC analysis
%                       3: QC on raw coordinate
%                       4: general analysis
%                       otherwise: first run analysis
%    InputData:         double matrix {telomere#,[alpha,D,GOF],2}
%                       while: row- number of telomeres
%                          column 1: anomalous exponent
%                          column 2: diffusion coefficient
%                          column 3: goodness of the fit
%                          (:,:,1) before tau=7sec
%                          (:,:,2) after  tau=7sec
%    FigParameter:       struct with at least the following fields:
%          .CellType       cell line MEF3T3 or MEFLmnaKO
%          .CurrentCell    cell number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        DataVecors         Data for histogram plot; struct with fields:
%           .First          the first sieries for histogram. double{N,1}
%           .secound        the secound sieries for histogram. double{N,1}
%           .MeanValues     the mean values double[1st,2nd]
%           .STDValues      the standard diviation values double[1st,2nd]
%           .VarValues      the Variance values double[1st,2nd]
%        TitlesInfo         specifiy titles strings; struct with fields:
%           .titles         figure title title string
%           .lagends        cellarray{1x2} with lagend strings
%           .AxisTitles     cellarray{1x2} with  axis label strings
%           .FigureName     string for the figure name
%           .FileName       name of the figure file to be saved
%        Parameter          specifiy plot parameters; struct with fields:
%           .NumBins        number of bins
%           .Normalization  normalization method
%           .EdgeColor      bin edge color
%           .BinWidth       the with of the bins
%           .FigSaveFormat  format of the figure file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function [DataVecors,TitlesInfo,Parameter] = GenerateHistAuxParameter...
    (Client,InputData,FigParameter)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Client~=5
    DataVecors=struct();
    % tau<7sec
    DataVecors.First=InputData(:,1,1);
    % tau>7sec
    DataVecors.secound=InputData(:,1,2);
    % mean values
    DataVecors.MeanValues=[mean(DataVecors.First),mean(DataVecors.secound)];
    % standard diviation values
    DataVecors.STDValues=[std(DataVecors.First),std(DataVecors.secound)];
    % Variance values
    DataVecors.VarValues=[var(DataVecors.First),var(DataVecors.secound)];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% define titles %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    TitlesInfo=struct();
    % spacify title
    TitlesInfo.titles={'\alpha_L_o_w','\alpha_H_i_g_h'};
    % specify lagend
    TitlesInfo.lagends={'\tau <7sec','\tau >7sec'};
    % specify axis titles
    TitlesInfo.AxisTitles={'anomalous exponent','probability'};
end
switch Client
    case 1
        % specify figure name
        TitlesInfo.FigureName='anomalous exponent hist Raw Analysis';
        % specify figure file name for saving
        TitlesInfo.FileName=[FigParameter.CellType,...
            '',num2str(FigParameter.CurrentCell),...
            '_anomalous exponent histogram Raw Analysis'];
    case 2
        % specify figure name
        TitlesInfo.FigureName='anomalous exponent hist QC';
        % specify figure file name for saving
        TitlesInfo.FileName=[FigParameter.CellType,...
            '',num2str(FigParameter.CurrentCell),...
            '_anomalous exponent histogram QC Analysis'];
    case 3
        % specify figure name
        TitlesInfo.FigureName='anomalous exponent hist RawQC';
        % specify figure file name for saving
        TitlesInfo.FileName=[FigParameter.CellType,...
            '',num2str(FigParameter.CurrentCell),...
            '_anomalous exponent histogram RawQC Analysis'];
    case 4
        % specify figure name
        TitlesInfo.FigureName='anomalous exponent hist general';
        % specify figure file name for saving
        TitlesInfo.FileName=[FigParameter.CellType,...
            '_anomalous exponent histogram general Analysis'];
    case 5
        % specify figure name
        TitlesInfo.FigureName='anomalous exponent hist general raw';
        % specify figure file name for saving
        TitlesInfo.FileName=[FigParameter.CellType,...
            '_anomalous exponent histogram general Analysis raw'];
        % data handel
        DataVecors=struct();
        % corrected
        DataVecors.First=InputData{1,1}(:,1,1);
        % raw 
        DataVecors.secound=InputData{1,2}(:,1,2);
        % mean values
        DataVecors.MeanValues=[mean(DataVecors.First),mean(DataVecors.secound)];
        % standard diviation values
        DataVecors.STDValues=[std(DataVecors.First),std(DataVecors.secound)];
        % Variance values
        DataVecors.VarValues=[var(DataVecors.First),var(DataVecors.secound)];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% define titles %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % spacify title
    TitlesInfo.titles={'\alpha _C_o_r_r_e_c_t_e_d','\alpha _r_a_w'};
    % specify lagend
    TitlesInfo.lagends={'corrected','raw'};
    % specify axis titles
    TitlesInfo.AxisTitles={'anomalous exponent','probability'};
    otherwise
        % specify figure name
        TitlesInfo.FigureName='anomalous exponent hist First Analysis';
        % specify figure file name for saving
        TitlesInfo.FileName=[FigParameter.CellType,...
            '',num2str(FigParameter.CurrentCell),...
            '_anomalous exponent histogram First Analysis'];
end

%%%%%%%%%%%%%%%%%%%%%%%%% specifiy plot parameters %%%%%%%%%%%%%%%%%%%%%%%%
Parameter=struct();
Parameter.NumBins=20;                   % number of bins
Parameter.Normalization='probability';  % normalization method
Parameter.EdgeColor='k';                % bin edge color
Parameter.BinWidth = 0.15;              % the with of the bins
Parameter.FigSaveFormat= 'bmp';         % format of the figure file
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
