%% QC Function: EstimateLocalizationError
% This function estimates the localization error for axial and lateral MSD
% curves, according to the equation LE = (sigma^2)./(D.*Dt)
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       DataFolders:        paths to load files with parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       LocalizationError:  vector 2 by 5; while: 
%                           (1,:) Lateral error (2,:) Axial error 
%                           columns are phases. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function LocalizationError = EstimateLocalizationError(DataFolders)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define local parameters
PhasesName = {'G0','S','G2','LateG2','UT'};
CellTypeName = {'MEF3T3','MEFLmnaKO'};
% frame rate (exposure time)
Dt = 0.1;
% diffusion constant (3D)
load(['',DataFolders{1,1},'\Results.mat'],'Results');
D=[Results.ParameterMat.G0.MEF3T3(1,1,2),...
    Results.ParameterMat.S.MEF3T3(1,1,2),...
    Results.ParameterMat.G2.MEF3T3(1,1,2),...
    Results.ParameterMat.LateG2.MEF3T3(1,1,2),...
    Results.ParameterMat.UT.MEF3T3(1,1,2)];
clear Results
%% import MSD data
fprintf('import ensemble MSD data\n');

% Lateral
load(['',DataFolders{1,2},'\Results.mat'],'Results');
LateralMSD = Results.MMSD;
clear Results

% Axial
load(['',DataFolders{1,3},'\Results.mat'],'Results');
AxialMSD = Results.MMSD;
clear Results

% collect data
for i=1:numel(PhasesName)
    
    eval(['Data{1,i} = LateralMSD.',PhasesName{1,i},...
        '.',CellTypeName{1,1},';']);
    eval(['Data{2,i} = AxialMSD.',PhasesName{1,i},...
        '.',CellTypeName{1,1},';']);
    
end
%% calculate sigma values
fprintf('calculate sigma values\n');
sigma=zeros(2,5);
for j=1:2
    for i=1:5
        x=[0.1:0.1:0.3];
        y=Data{j,i};
        % Prepare data inputs for curve fitting.
        [xData, yData] = prepareCurveData( x, y(1:3) );
        % Set up fittype and options.
        ft = fittype( 'poly1' );
        % Fit model to data.
        [fitresult, ~] = fit( xData, yData, ft );
        % extract coefficients
        MyCoeffs = coeffvalues(fitresult);
        sigma(j,i) = MyCoeffs(2);
    end
end

%% calculate localization error

LocalizationError=zeros(2,5);
for j=1:2
    for i=1:5
        LocalizationError(j,i) = sigma(j,i)./(D(i).*Dt);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
