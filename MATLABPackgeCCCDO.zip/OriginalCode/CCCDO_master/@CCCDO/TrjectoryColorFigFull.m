%% Figure Function: TrjectoryColorFigFull
% this function generates trajectory coordinate figure when the time is 
% coded to color and X,Y,Z are also presented separately  
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       time:           vector of time 
%       coordinates:    vector [x,y,z]
%       titleStr        cell array with titles for the figure:
%                       {1,1} figure window name 
%                       {1,2} figure title 
%                       {1,3} figure file name 
%                       {1,4} figure file format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% no output for this function %%%%%%%%%%%%%%%%%%%%%%%       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function TrjectoryColorFigFull(time,coordinates,titleStr)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('name',['',titleStr{1,1}],'NumberTitle','off');

subplot(2,2,1);

% encode time to colormap
cm = jet(length(time));
colormap(cm);
color_scale = linspace(0,size(cm,1),numel(time));
% plot 3D phase plane
x=coordinates(:,1);y=coordinates(:,2);z=coordinates(:,3);
% ignor null trajectories
Test=find(~isnan(x));
if isempty(Test)
   return 
end
surf([x,x],[y,y],[z,z],[color_scale',color_scale'],...
    'EdgeColor','flat', 'FaceColor','none');
% % fix axis scale
% xlim([min(x)-0.5 max(x)+0.5]);
% ylim([min(y)-0.5 max(y)+0.5]);
% zlim([min(z)-0.5 max(z)+0.5]);

% specify colorbar proporties
c = colorbar;
c.Label.FontSize=12;
c.Ticks=0:(length(time)/3):length(time);
c.TickLabels={'0','50','100','150'};
c.Location='SouthOutside';
c.Label.String='time[sec]';

ylabel('Y [\mu m]');
xlabel('X [\mu m]');
zlabel('Z [\mu m]')
title(['',titleStr{1,2}]);


subplot(2,2,2);
plot(time,z);
ylim([min(z)-0.5 max(z)+0.5]);
title('Axial (Z)');
xlabel('time[sec]');
ylabel('Z[\mu m]')
subplot(2,2,3);
plot(time,x);
ylim([min(x)-0.5 max(x)+0.5]);
title('Lateral (X)');
ylabel('X[\mu m]')
subplot(2,2,4);
plot(time,y);
ylim([min(y)-0.5 max(y)+0.5]);
title('Lateral (Y)');
ylabel('Y[\mu m]')


set(gcf,'position',[467 96 1103 853]);
saveas(gcf,['',titleStr{1,3}],['',titleStr{1,4}]);

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end