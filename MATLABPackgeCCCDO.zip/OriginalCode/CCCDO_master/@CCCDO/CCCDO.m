%% class: CCCDO
%% script starts here %%
classdef (Sealed) CCCDO 
%%%%%%%%%%%%%%%%%%%%% start of class definition %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%% properties %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    properties
        %%%%%%%%%%%% input %%%%%%%%%%%
        FuncIdx;
        UDparam;
        
        %%%%%%%%%%%% output %%%%%%%%%%
        Results;
    end
   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%% methods %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %% Property Set Methods
    % default calling for this class will run pipeline function as
    % specified by FuncIdx
    % 1: SingleCellAnalysis
    % 2: GeneralAnalysis
    % 3: EnsembleRun
    methods
        function self = CCCDO(FuncIdx,UDparam,varargin)
            self.FuncIdx = FuncIdx;
            self.UDparam=UDparam;
            % Default calling by run mode index
            switch self.FuncIdx
                case 1
                    self.Results = CCCDO.SingleCellAnalysis...
                        (self.UDparam.ExperimentFolder,...
                        self.UDparam.NumFrames,...
                        varargin{1},...
                        self.UDparam.CellType,...
                        self.UDparam.MinLength);
                case 2
                    self.Results = CCCDO.GeneralAnalysis...
                        (varargin{1},self.UDparam.ExperimentFolder,...
                        self.UDparam.ExcludedCells,...
                        self.UDparam.numCells,varargin{2});
                case 3
                    self.Results = CCCDO.EnsembleMSD...
                        (varargin{1},varargin{2},varargin{3});
                otherwise
                    self.Results=struct();
            end
        end
    end
    %% methods : Run Mode Function
    methods (Access = public,Static)
        %%%%%%%%%%%%% Run Mode Function: SingleCellAnalysis %%%%%%%%%%%%%%%
        % (FuncIdx=1) This function run MSD analysis for single cell
        AnalysisResults = SingleCellAnalysis...
            (ExperimentFolder,NumFrames,ThisCell,CellType,MinLength);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%% Run Mode Function: GeneralAnalysis %%%%%%%%%%%%%%%%%%
        %(FuncIdx=2)
        % This function summarizes all trajectories data from single 
        % experiment. using 3D (x,y,z) data.
        GeneralAnalysisResults = GeneralAnalysis...
            (ExperimentTitle,ExperimentFolder,...
            ExcludedCells,numCells,DataFolder);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%% Run Mode Function: EnsembleMSD %%%%%%%%%%%%%%%%%%
        % (FuncIdx=3) This function calculates anomalous exponent and
        % diffusion coefficient.
        % compare between cell cycle phase and between 
        % cell lines (MEF 3T3 and MEF LmnaKO) 
        Results =...
            EnsembleMSD(ExperimentFolder,FolderName,Dimensionality);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%% Run Mode Function: Main2D %%%%%%%%%%%%%%%%%%%%
        % This function summarizes all trajectories data from single 
        % experiment. using only Lateral (x,y) data.
        LateralMSD = Main2D...
            (ExperimentFolder,ExcludedCells,numCells);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%% Run Mode Function: MainZ %%%%%%%%%%%%%%%%%%%%%
        % This function summarizes all trajectories data from single 
        % experiment. using only Axial (z) data.
        % identify transition times inspired by De-Gennes model.
        AxialMSD = MainZ(ExperimentFolder,ExcludedCells,numCells);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%% Run Mode Function: SummaryRun %%%%%%%%%%%%%%%%%% 
        % ('SummaryRun', FuncIdx=6) This function calculates the "
        % constraining volume"- the mean volume "visited" by a random
        % telomere in each phase of the cell cycle. This value represents
        % the constraint level of the specific cell cycle phase.
        Results = SummaryRun (ExperimentFolder, TimeAve);
        ConvexHullAnalysis(TimeAve);
            
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
    end
    
    %% methods: Pipeline functions  
    methods(Access = public,Static)
        
        %%%%%%%%%%%%%%%% Pipeline Function: BiLinearFitPlot %%%%%%%%%%%%%%%
        % generate linear fit: log10(MSD/tau)=(alpha-1)log10(tau)+log10(D) 
        % for before and after specified time. this function is used to 
        % find the transition times (Tr and TL)
        CoefficientVec = BiLinearFitPlot...
            (FigParameter,TauVec,Data,MinLength);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Pipeline Function: TauCutoffFind
        TransitionTime = TauCutoffFind(MSD,MaxT);
        % Pipeline Function: CalculateCoefficient
        [CoefficientVec,ParameterMat] = CalculateCoefficient ...
            (tauCut,MSD,PhasesName,CellTypeName,FigParameter,...
            FolderName,TauVec,MinLength);
        % Pipeline Function: CalculateMSD
        [TauVec,MSDVec] = ...
            CalculateMSD(Data,IntervalTime,FinalFrame,Dimensionality);
    end
    %% methods: Figure functions 
    
    methods(Access = public,Static)
        
        %%%%%%%%% Figure Function: TrjectoryColorFigFull %%%%%%%%%%%%%%%%%%
        % this function generates trajectory coordinate figure when the
        % time is coded to color and X,Y,Z are also presented separately
        TrjectoryColorFigFull(time,coordinates,titleStr);
        %%%%%%%%%%%%%%% Figure Function: TrjectoryColorFig %%%%%%%%%%%%%%%%
        % this function generate trajectory coordinat figure when the time
        % is coded to color, using smooth filter.
        TrjectoryColorFig(time,coordinates,titleStr,varargin);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % plot MSD curve of single trajectory
        MSDCurvePlot(FigParameter,TauVec,Data);
        
        % plot anomalous exponent histograms for 2 series  
        GenerateHist (DataVecors,TitlesInfo,Parameter);
        
        % plot Ensemble MSD curves for all phases, for the two cell lines
        MMSD2(PhasesName,CellTypeName,MSD,Dimensionality,MaxT);
        
        % generates different types of Ensemble MSD curves.
        MeanMSDFig(PhasesName,CellTypeName,MSD,idx,Dimensionality,MaxT);
        
        %%%%%%%%%%%%%%%%%% Figure Function: ViolinFig %%%%%%%%%%%%%%%%%%%%%
        % This function generates violin figure for the anomalous exponent
        % distribution data in all cell cycle phases according to
        % transition times detected by the ensemble MSD vectors.
        ViolinFig(FolderName,PhasesName,CellTypeName,...
            CoefficientVec,CaseRun,Dimensionality);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%% Figure Function: FitMMSD %%%%%%%%%%%%%%%%%%%%%%
        % This function receives ensemble MSD vector, and fit linear curve
        % for the short and long times separately, as determined by
        % transition time vector
        FitMMSD(TransitionTime,MMSD,MaxT,Dimensionality,varargin);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Draw Constraining Volume figures
        DrawConstrainingVolume(MeanConstrainingRadius,varargin);
        %%%%%%%%%%%%%%%%%% Figure Function: ViolinCV %%%%%%%%%%%%%%%%%%%%%%
        % This function generate violin plot three types of constraining
        % volume: ellipsoid combines lateral and axial radiuses, 
        % V = (4/3)pi*(Rxy^2)*(Rz) spear base on lateral only information, 
        % V = (4/3)pi*(Rxy^3) spear base on Axial only information, 
        % V = (4/3)pi*(Rz^3)
        ViolinCV(Data,idx);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        ViolinCVH(Data,idx);
        
        CvHFigure(CVH,Dimensionality,idx,FolderName);
    end
    
    %% methods: QC functions
    methods(Access = public,Static)
        %%%%%%%%%%%%%%% QC Function: GenerateLinaearFigSC %%%%%%%%%%%%%%%%% 
        % generate linear fit figure for each trajectory
        GenerateLinaearFigSC(MaxT);
        GenerateLinaearFigSCAxial(MaxT);
        GenerateLinaearFigSCLateral(MaxT);
        %%%%%%%%%%%%%%%%%%% QC Function: RemoveTrj %%%%%%%%%%%%%%%%%%%%%%%%
        % exclude bad fitted trajectories
        RemoveTrj(idx);
        %%%%%%%%%%%%% QC Function: EstimateLocalizationError %%%%%%%%%%%%%% 
        % estimates the localization error for axial and lateral MSD
        % curves, according to the equation LE = (sigma^2)./(D.*Dt)
        LocalizationError = EstimateLocalizationError(ExperimentFolder);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%% QC Function: ExtractStatistics %%%%%%%%%%%%%%%%%%% 
        % This function collects statistical parameters
        StatisticsMat = ...
            ExtractStatistics(FolderName,PhaseName,CellTypeName);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%% QC Function: CalculateSignificance %%%%%%%%%%%%%%%%%
        % This function calculates distribution p value with confidence 
        % of 80%,95%,99% and 99.9%
        [AlphaPvalueMat,DPvalueMat,varargout] = ...
            CalculateSignificance(Dimensionality);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
    
    %% methods: Auxiliary functions
    methods(Access = public,Static)
        
        % Auxiliary Function: ArrengeAllData
        LinkData = ArrengeAllData ...
            (ExperimentFolder,NumFrames,ThisCell,MinLength);
        
        % Auxiliary Function: ArrengeTrajectories
        [Trajectories,TrjLength] = ArrengeTrajectories...
            (ExperimentFolder,NumFrames,ThisCell,MinLength);
        
        % Auxiliary Function: ArrengeMSDs
        [MSD,MSDlength] = ...
            ArrengeMSDs (ExperimentFolder,NumFrames,ThisCell,MinLength,~);
        
        % Auxiliary Function: ArrengeAffineMat
        AffineMat = ArrengeAffineMat...
            (ExperimentFolder,NumFrames,ThisCell);
        
        % Auxiliary Function: MMSDMain
        MMSDMain(FolderName,MSD,Dimensionality,MaxT);
        
        %%%%%%%%%%%%%%%%%%% Auxiliary function: violin %%%%%%%%%%%%%%%%%%%%
        % revision of Simple violin plot using matlab default kernel
        % density estimation.  credite declearation, original code writhen
        % by: Hoffmann H, 2015: violin.m - Simple violin plot using matlab
        % default kernel density estimation. INRES (University of Bonn),
        % Katzenburgweg 5, 53115 Germany. hhoffmann@uni-bonn.de
        [h,L,MX,MED,bw] = violin(Y,fc,varargin);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Auxiliary Function: SummaryAux
        Results = SummaryAux(DataFolders,TimeAve);
        
        %%%%%%%%% Auxiliary Function: CollectStatisticalParam %%%%%%%%%%%%%
        % This function load data files and arrange parameters matrix
        [DATA,StatisticsMat] = ...
            CollectStatisticalParam(DataFolders,PhaseNames,CellTypeName);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%% Auxiliary Function: CVHaux %%%%%%%%%%%%%%%%%%%%
        % This function using Convex Hull to calculate the scanning volume
        % of each trajectory until specific time (by defalt 25 s) , for one
        % experiment.
        [CVH,VcH] = CVHaux(T,numCells,Data,Dimensionality);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
%%%%%%%%%%%%%%%%%%%%%%% End of class definition %%%%%%%%%%%%%%%%%%%%%%%%%%%
end