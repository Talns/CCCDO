%% QC Function: RemoveTrj
% This function deletes bad fitted trajectories according to user definition
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           idx:                    cell 1 by 2;
%                                   {1,1} phase index:
%                                   {1:'G0',2:'S',3:'G2',4:'LateG2',5:'UT'}
%                                   {1,2} Cell line index
%                                   {1:'MEF3T3',2:'MEFLmnaKO'}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           None:                       no output for this function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function RemoveTrj(idx)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% import user defined parameteres
[ExperimentFolder,~,ExcludedCells,numCells,~,~,~,~,~, ExcludeTrj] = ...
    UserParameter(idx,0);
%% run on all cells and remove bad trjectories
for ThisCell=1:numCells
    if ismember(ThisCell,ExcludedCells)
        continue
    end
    if isfield(ExcludeTrj,['Cell_',num2str(ThisCell)])
        %% remove this cell bad trajectories
        fprintf(['Correct Cell_',num2str(ThisCell),'\n']);
        % change directory to the cell folder
        cd([ExperimentFolder,'\Analysis\Cell_',num2str(ThisCell)]);
        load('ResultsAnalysis.mat','AnalysisResults');
        load(['Cell_',num2str(ThisCell),'_LinkData.mat'],...
            ['Cell_',num2str(ThisCell)]);
        if ~isfolder([ExperimentFolder,...
                '\Analysis\Cell_',num2str(ThisCell),'\AllTrajectories'])
            mkdir([ExperimentFolder,'\Analysis\Cell_',num2str(ThisCell)],...
                'AllTrajectories');
            cd([ExperimentFolder,...
                '\Analysis\Cell_',num2str(ThisCell),'\AllTrajectories']);
            save('ResultsAnalysis.mat','AnalysisResults');
            save(['Cell_',num2str(ThisCell),'_LinkData.mat'],...
            ['Cell_',num2str(ThisCell)]);
            cd([ExperimentFolder,'\Analysis\Cell_',num2str(ThisCell)]);
        end
        % copy bad indexes
        eval(['BadTrj = ExcludeTrj.Cell_',num2str(ThisCell)]);
        % delete bad trajectories
        MSD=AnalysisResults.MSD;
        eval(['Trajectories = Cell_',num2str(ThisCell),'.Trajectories;']);
        MSD(:,BadTrj,:)=[];
        Trajectories(BadTrj,:,:) = [];
        eval(['Cell_',num2str(ThisCell),'.Trajectories = Trajectories;']);
        AnalysisResults.MSD = MSD;
        save('ResultsAnalysis.mat','AnalysisResults');
        save(['Cell_',num2str(ThisCell),'_LinkData.mat'],...
            ['Cell_',num2str(ThisCell)]);
        clearvars 'Cell_*' Trajectories
    end
    cd([ExperimentFolder,'\Analysis']);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
