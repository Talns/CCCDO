%% QC Function: GenerateLinaearFigSC
% This function generates linear fit figures, for each trajectory, cell by
% cell and for all phases and cell lines.
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       MaxT:                 Last frame to be included for calculation of
%                             MSD coefficients
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:                 No output for this function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function GenerateLinaearFigSC(MaxT)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% define general parmetes

Dimensionality=3;

% import data folders path
idx{1,1}=0;
idx{1,2}=3;
[~,~,~,~,~,NumFrames,~,PhaseNames,CellTypeName, DATAFolders] = ...
    UserParameter(idx,0);


%% collect parameters for this experiment
for k=1:2
    for j=1:5
        idx{1,1}=j;
        idx{1,2}=k;
        [~,~,ExcludedCells,numCells,~,~,~,~,~,ExcludeTrj] =...
            UserParameter(idx,0);
        %% change to figure saving path
        ParentFolder=[DATAFolders{k,j},'\Analysis\LinearFig'];
        if isfolder(ParentFolder)
            cd(ParentFolder);
        else
            mkdir([DATAFolders{k,j},'\Analysis'],'LinearFig');
            cd(ParentFolder);
            mkdir(ParentFolder,'SuperDiffusion');
            mkdir(ParentFolder,'SubDiffusion');
            mkdir(ParentFolder,'ExtremeSubDiffusion');
            mkdir(ParentFolder,'Trj');
            mkdir(ParentFolder,'ExTrj');
        end
        SaveFolderes = {[ParentFolder,'\SuperDiffusion']...
            [ParentFolder,'\ExtremeSubDiffusion'],...
            [ParentFolder,'\SubDiffusion'],...
            [ParentFolder,'\Trj']};
        %%
        load([DATAFolders{k,j},'\Analysis\TransitionTime.mat'], 'TransitionTime');
        for m=1:numCells
            if ismember(m,ExcludedCells)
                continue
            else
                %% define cell
                ThisFolder = [DATAFolders{k,j},'\Analysis\Cell_',num2str(m)];
                fprintf(['Cell: ',num2str(m),'\n']);
                %% generate this cell fit figures
                %                 cd(ThisFolder);
                if isfield(ExcludeTrj,['Cell_',num2str(m)])
                    load([ThisFolder,'\AllTrajectories\ResultsAnalysis.mat'],...
                        'AnalysisResults');
                    eval(['ExTrj = ExcludeTrj.Cell_',num2str(m),';']);
                    load([ThisFolder,'\AllTrajectories\Cell_',...
                        num2str(m),'_LinkData.mat'],['Cell_',num2str(m)]);
                    eval(['Trj = Cell_',num2str(m),'.Trajectories;']);
                    Trj = permute(Trj,[3,2,1]);
                else
                    load([ThisFolder,'\ResultsAnalysis.mat'],...
                        'AnalysisResults');
                    load([ThisFolder,'\Cell_',num2str(m),...
                        '_LinkData.mat'],['Cell_',num2str(m)]);
                    eval(['Trj = Cell_',num2str(m),'.Trajectories;']);
                    Trj = permute(Trj,[3,2,1]);
                    ExTrj=[];
                end
                
                MSD = AnalysisResults.MSD(:,:,1);
                
                % save figures
                for i=1:size(MSD,2)
                    if i==15
                        continue
                    end
                    if ismember(i,ExTrj)
                       FolderNames = cell(1,4);
                       FolderNames{1,1} = [ParentFolder,'\ExTrj'];
                       FolderNames{1,2} = FolderNames{1,1};
                       FolderNames{1,3} = FolderNames{1,1};
                       FolderNames{1,4} = FolderNames{1,1};
                    else
                        FolderNames = SaveFolderes;
                    end
                    %%%%%%%%%%%%%%%%%%%%% linear fit %%%%%%%%%%%%%%%%%%%%%%
                    Data=MSD(:,i);
                    CCCDO.FitMMSD(TransitionTime,Data,MaxT,Dimensionality,...
                        [CellTypeName{1,k},'_',PhaseNames{1,j},...
                        '_Cell_',num2str(m),'_Trj_',num2str(i)],FolderNames);
                    %%%%%%%%%%%%%%%% Trajectories %%%%%%%%%%%%%%%%%%%%%%%%%
                    time = [1:NumFrames].*0.1;
                    
                    % titleStr cell array with titles for the figure:
                    %          {1,1} figure window name 
                    %          {1,2} figure title 
                    %          {1,3} figure file name 
                    %          {1,4} figure file format
                    titleStr=cell(1,4);
                    titleStr{1,1} = [CellTypeName{1,k},' ',PhaseNames{1,j},...
                        ' Cell',num2str(m),' Trj',num2str(i)];
                    titleStr{1,2} = [CellTypeName{1,k},' ',PhaseNames{1,j},...
                        ' Cell',num2str(m),' Trj',num2str(i)];
                    titleStr{1,3} = [FolderNames{1,4},'\',...
                        CellTypeName{1,k},'_',PhaseNames{1,j},...
                        '_Cell_',num2str(m),'_Trj_',num2str(i)];
                    titleStr{1,4} = 'bmp';
                    coordinates = Trj(:,:,i);                    
                    CCCDO.TrjectoryColorFigFull(time,coordinates,titleStr);
                    clear coordinates
                end
                close all;
                
            end
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
