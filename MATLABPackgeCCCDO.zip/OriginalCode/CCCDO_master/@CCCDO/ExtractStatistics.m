%% QC Function: ExtractStatistics
% This function collects statistical parameters   
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       FolderName:             parent folder with all experimental data 
%       PhaseNames:             cell cycle phases. cell 1 by 5
%                                   {'G0','S','G2','LateG2','UT'}
%       CellTypeName:           cell line names.{'MEF3T3','MEFLmnaKO'} 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       StatisticsMat:      struct with fields:
%           .1st level          fieldnames: Full,Lateral,Axial; each one is 
%                               a struct with fields: 
%               .2nd level      fieldnames:'MEF3T3','MEFLmnaKO'; 
%                               each one is vector 14 by 5, while column-
%                               cell cycle phase and rows are: (1) Tr,
%                               (2)TL anomalous exponent (3) short (4) long
%                               variance respectively (5) short (6) long
%                               std      respectively (7) short (8) long
%                               diffusion constant (9) mean (10) std 
%                               1st level = 'Full'only 
%                               (11) number of trajectories (12) mean
%                               Pearson
%           .LocalizationError: vector 2 by 5; while: 
%                               (1,:) Lateral error (2,:) Axial error 
%                               columns are phases. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function StatisticsMat = ...
    ExtractStatistics(FolderName,PhaseNames,CellTypeName)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define parameters
DataFolders = cell(1,4);
DataFolders{1,1} = [FolderName,'\EnsembleAnalysis\Full'];
DataFolders{1,2} = [FolderName,'\EnsembleAnalysis\Lateral'];
DataFolders{1,3} = [FolderName,'\EnsembleAnalysis\Axial'];
DataFolders{1,4} = [FolderName,'\EnsembleAnalysis\SummaryAnalysis'];
%% collect data
if exist([DataFolders{1,4},'\Statistics.mat'],'file')
    load([DataFolders{1,4},'\Statistics.mat'],'DATA','StatisticsMat');
else
    [DATA,StatisticsMat] = CCCDO.CollectStatisticalParam(DataFolders,...
        PhaseNames,CellTypeName);
    save([DataFolders{1,4},'\Statistics.mat'],'DATA','StatisticsMat');
end
%% estimate localization error
if ~isfield(StatisticsMat,'LocalizationError')
    StatisticsMat.LocalizationError =...
        CCCDO.EstimateLocalizationError(DataFolders);
    save([DataFolders{1,4},'\Statistics.mat'],'DATA','StatisticsMat');
end
%% confidence test
fprintf('confidence test\n');
for Dimensionality =1:3
    [~,~,~] = ...
        CCCDO.CalculateSignificance(Dimensionality);
end
%% convert to table
PhasesName=PhaseNames;

RowTitle={'TransitionTime [sec]';'Anomalous exponent';'variance';...
    'diffusion constant [um^2/sec^alpha]';'number of trajectories';...
    'Pearson';'Localization error [nm] : lateral, axial'};
%%%%%%%%%%%%%%%%%%%%%%% generate cell array   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Data=StatisticsMat.Full.MEF3T3;
LE=StatisticsMat.LocalizationError;
for i=1:5
temp={[num2str(Data(1,i)),',',num2str(Data(2,i))];...
    ['low: ',num2str(Data(3,i),'%.2f'),' +/- ',num2str(Data(7,i),'%.2f'),...
    ' High: ',num2str(Data(4,i),'%.2f'),' +/- ',num2str(Data(8,i),'%.2f')];...
    [num2str(Data(5,i),'%.2f'),',',num2str(Data(6,i),'%.2f')];...
    [num2str(Data(9,i),'%.2e'),' +/- ',num2str(Data(10,i),'%.2e')];...
    [num2str(Data(11,i))];...
    [num2str(Data(12,i),'%.2f')];...
    [num2str(LE(1,i),'%.0f'),',',num2str(LE(2,i),'%.0f')]};
eval([PhasesName{1,i},'= temp;']);
end
% print to command line
table(RowTitle,G0,S,G2,LateG2,UT)

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
