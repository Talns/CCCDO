%% Figure Function: FitMMSD
% This function receives ensemble MSD vector, and fit linear curve for the
% short and long times separately, as determined by transition time vector
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       TransitionTime:       Transition time separate between short
%                             times t<Tr and longer times t>TL; 
%                             vector [Tr,TL]
%       MMSD:                 ensemble MSD vector 
%       MaxT:                 Last frame to be included for calculation of
%                             MSD coefficients 
%       Dimensionality:     type of analysis: 
%                               1- Axial(Z), 2- Lateral(xy),3- 3D analysis       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:                 No output for this function 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%
function FitMMSD(TransitionTime,MMSD,MaxT,Dimensionality,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% transition times
Tr=TransitionTime(1);
TL=TransitionTime(2);

% time vector
Tau=[1:1500].*0.1;
% loglog scale
x=log10(Tau);
y=log10(MMSD./Tau');
if ~isempty(varargin{1})
    SaveFolderes=varargin{2};
end
% type of analysis
AnalysisName={'Axial','Lateral','Full'}; 
%% generate fit for short and long times for MMSD
MFitAlpha=zeros(2,3);
for j=1:2
    
    figure('Name',['Fit ',num2str(j)],'NumberTitle','off');
    [xData, yData] = prepareCurveData( x, y );
    % Set up fittype and options.
    ft = fittype( 'poly1' );
    if j==1
        excludedPoints = excludedata( xData, yData, 'Indices', [Tr:length(x)] );
    else
        excludedPoints = excludedata( xData, yData, 'Indices', [1:TL,MaxT:length(x)] );
    end
    opts = fitoptions( 'Method', 'LinearLeastSquares' );
    opts.Exclude = excludedPoints(1:length(xData));
    
    % Fit model to data.
    [fitresult, gof] = fit( xData, yData, ft, opts );
    h = plot( fitresult, xData, yData, excludedPoints(1:length(xData)) );
    xlabel ('log10(time) [sec]');
    ylabel ('log10(MSD/time) [\mu m^2/sec]');

    % extract coefficients
    MyCoeffs = coeffvalues(fitresult);
    % save anomulous exponent (alpha)
    MFitAlpha(j,1) = MyCoeffs(1)+1;
    % save Diffusion constant (D)
    MFitAlpha(j,2) = (10^MyCoeffs(2));
    % save goodness of fit
    MFitAlpha(j,3)=gof.rsquare;
    title(['\alpha = ',num2str(MFitAlpha(j,1),'%.2f'),...
        ' R^2 = ',num2str(MFitAlpha(j,3),'%.2f')]);
    % save figure
    if ~isempty(varargin{1})
        if j==1
        saveas(gcf,['Fit ',num2str(j),' ',varargin{1}],'bmp');
        elseif j==2
            if MFitAlpha(2,1)>=1
                saveas(gcf,[SaveFolderes{1,1},'\Fit ',...
                    num2str(j),' ',varargin{1}],'bmp');
            elseif MFitAlpha(2,1) <= 0.1
                saveas(gcf,[SaveFolderes{1,2},'\Fit ',...
                    num2str(j),' ',varargin{1}],'bmp');
            else
                saveas(gcf,[SaveFolderes{1,3},'\Fit ',...
                    num2str(j),' ',varargin{1}],'bmp');
            end
        end
    else
        saveas(gcf,['Fit ',num2str(j),' ',AnalysisName{Dimensionality}],'bmp');
    end
end
% save results
if isempty(varargin{1})
    save('MFitAlpha.mat','MFitAlpha');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
