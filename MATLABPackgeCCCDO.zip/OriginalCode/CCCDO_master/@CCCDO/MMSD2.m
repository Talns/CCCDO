%% Figure Function: MMSD2
% This function generates Ensemble MSD curves for all phases, for the two
% cell lines
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       PhasesName:         cell array with phases names
%                           {'G0','S','G2','LateG2','UT'}
%       CellTypeName:       cell array with cell lines names
%                           {'MEF3T3','MEFLmnaKO'}
%       MSD:                struct with field equal to PhasesName; each one of
%                           them is struct with field {'MEF3T3','MEFLmnaKO'}
%                           with MSD vectors of all trajectories in this phase
%       Dimensionality:     type of analysis: 
%                               1- Axial(Z), 2- Lateral(xy),3- 3D analysis
%       MaxT:              Last frame to be included for MSD calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       None:           No outputs for this function  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function MMSD2(PhasesName,CellTypeName,MSD,Dimensionality,MaxT)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Dimensionality==1
    limits=[-3.5,0,-1,2,MaxT];
else
    limits=[-3.5,-1,-1,2,MaxT];
end
IntervalTime=0.1;

% collect data
for i=1:numel(PhasesName)
    for j=1:2
        
        eval(['Data{j,i} = MSD.',PhasesName{1,i},'.',CellTypeName{1,j},';']);
    end
end

figure('name','MMSD2','NumberTitle','off');
colornames={'b','g','m','r','k'};

for j=1:2
    subplot(1,2,j);
    for i=1:numel(PhasesName)
        MMSD=mean(Data{j,i}(:,:,1),2,'omitnan');
        tau=(1:length(MMSD))'.*IntervalTime;
        x=log10(tau(2:limits(5)));
        y=log10(MMSD(2:limits(5))./tau(2:limits(5)));
        plot(x,y,colornames{1,i});
        ylim([limits(1),limits(2)]);
        
        hold on;
        
    end
    xlim([limits(3),limits(4)]);
    legend(PhasesName{:});
    title(CellTypeName{1,j});
    box off;
    ylabel('<r^2>/\tau   [\mu m^2/sec]','fontsize',14);
    xlabel('\tau [sec]','fontsize',14);
    
end
set(gcf,'position',[580 333 971 645]);
saveas(gcf,'MMSD2','bmp');

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
