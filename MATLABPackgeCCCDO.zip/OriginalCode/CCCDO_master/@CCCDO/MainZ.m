%% Main Function: MainZ
% This function summarizes all trajectories data from single experiment.
% using only Axial (z) data.
% identify transition times inspired by De-Gennes model.
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       ExperimentFolder:           folder of the experiment
%       ExcludedCells:              cell to be excluded from analysis
%       numCells:                   number of cells
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       AxialMSD:               struct with fields:
%           .GeneralCoVec:         double matrix {telomere#,[alpha,D,GOF],3} 
%                                  while:   row- number of telomeres
%                                           column 1: anomalous exponent
%                                           column 2: diffusion coefficient
%                                           column 3: goodness of the fit
%                                           (:,:,1)    tau<Tr
%                                           (:,:,2)    tau>TL
%           .TransitionTime:       Transition time separate between short
%                                  times t<Tr and longer times t>TL; 
%                                  vector [Tr,TL]
%           .generalMSD:           Double M by N by 5 while:
%                                   rows: time-points 
%                                   columns: trajectories 
%                                   (:,:,1) MSD values
%                                   (:,:,2) pairs count in each time point
%                                   (:,:,3) standard deviation
%                                   (:,:,4) t-test low value
%                                   (:,:,5) t-test high value
%           .MMSD:                  ensemble MSD vector 
%           .ParameterMat           matrix of parameters. while:
%                                   rows (Mean, variance, skewness, kurtosis)
%                                   column (low, high)
%                                   (:,:,1) alpha exponent
%                                   (:,:,2) D*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function AxialMSD = MainZ(ExperimentFolder,ExcludedCells,numCells)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define local parameter 
cd(ExperimentFolder);
load('GeneralAnalysisResults.mat');
Data=GeneralAnalysisResults.AllCellsData;
AxialMSD=struct();
generalMSD=[];
IntervalTime=0.1;
FinalFrame=1500;
Dimensionality=1;
MinLength=150;
MaxT=300;
tau=[1:1500].*IntervalTime;
ExperimentTitle=GeneralAnalysisResults.ExperimentTitle;
%% calculate general MSD vector from Axial co-ordinate only
AllTrajectoriesMSD=struct();
for i=1:numCells
    if ismember(i,ExcludedCells)
       continue 
    end
    if isfield(Data,['Cell_',num2str(i)])
        eval(['temp = Data.Cell_',num2str(i),'.Trajectories;']);
        
        fprintf(['Cell: ',num2str(i),'\n']);
        [~,temp1] = CCCDO.CalculateMSD...
            (temp,IntervalTime,FinalFrame,Dimensionality);
        eval(['AllTrajectoriesMSD.Cell_',num2str(i),' = temp1;']);
        generalMSD=horzcat(generalMSD,temp1);
        clear temp
    end
end
AxialMSD.MMSD = mean(generalMSD(:,:,1),2,'omitnan');
AxialMSD.generalMSD = generalMSD;
AxialMSD.AllTrajectoriesMSD = AllTrajectoriesMSD;
%% find Transition times and calculate coefficient 
if exist('Axial_TransitionTime.mat','file')
    load('Axial_TransitionTime.mat','TransitionTime');
    AxialMSD.TransitionTime=TransitionTime;
else
    TransitionTime = CCCDO.TauCutoffFind(generalMSD,MaxT);
    AxialMSD.TransitionTime=TransitionTime;
    save 'Axial_TransitionTime.mat' TransitionTime
end
% save example figures
CCCDO.FitMMSD(TransitionTime,AxialMSD.MMSD,MaxT,Dimensionality,[]);
%% caculate coeffieict for all trjectories
FigParameter.FigIdx=0;
fprintf('fiting 1st transition time\n');
FigParameter.EdgeTerms=[AxialMSD.TransitionTime(1),MaxT];
temp = CCCDO.BiLinearFitPlot(FigParameter,tau,generalMSD,MinLength);
GeneralCoVec(:,:,1)=temp(:,:,1);
fprintf('fiting 2nd transition time\n');
FigParameter.EdgeTerms=[GeneralAnalysisResults.TransitionTime(2),MaxT];
temp = CCCDO.BiLinearFitPlot(FigParameter,tau,generalMSD,MinLength);
GeneralCoVec(:,:,2)=temp(:,:,2);
% save co-efficients
AxialMSD.GeneralCoVec = GeneralCoVec;
%% generate parameter matrix
% anomalous exponent 
ParameterMat(:,:,1) = ...
    [mean(GeneralCoVec(:,1,1)),mean(GeneralCoVec(:,1,2));...
     var(GeneralCoVec(:,1,1)),var(GeneralCoVec(:,1,2));....
     skewness(GeneralCoVec(:,1,1)),skewness(GeneralCoVec(:,1,2));....
     kurtosis(GeneralCoVec(:,1,1)),kurtosis(GeneralCoVec(:,1,2));];
 % diffusion coefficient (D*)
 ParameterMat(:,:,2) = ...
    [mean(GeneralCoVec(:,2,1)),mean(GeneralCoVec(:,2,2));...
     var(GeneralCoVec(:,2,1)),var(GeneralCoVec(:,2,2));....
     skewness(GeneralCoVec(:,2,1)),skewness(GeneralCoVec(:,2,2));....
     kurtosis(GeneralCoVec(:,2,1)),kurtosis(GeneralCoVec(:,2,2));];
  AxialMSD.ParameterMat = ParameterMat;
%% save data
save 'AxialMSD.mat' AxialMSD
%% generate anomalous exponent histogram  
% define histogram parameter
Parameter.NumBins=10;                   % number of bins
Parameter.Normalization='probability';  % normalization method
Parameter.EdgeColor='k';                % bin edge color
Parameter.BinWidth = 0.15;              % the with of the bins
Limits=[0,2,0,0.75];

figure('name',ExperimentTitle,'NumberTitle','off');
% plot histogram for tau<7sec

h1=histogram(GeneralCoVec(:,1,1),'FaceColor','b');

h1.NumBins = Parameter.NumBins;
h1.Normalization = Parameter.Normalization;
h1.EdgeColor=Parameter.EdgeColor;
h1.BinWidth=Parameter.BinWidth;

hold on

h2=histogram(GeneralCoVec(:,1,2),'FaceColor','m');

h2.NumBins=Parameter.NumBins;
h2.Normalization=Parameter.Normalization;
h2.EdgeColor=Parameter.EdgeColor;
h2.BinWidth=Parameter.BinWidth;

xlim([Limits(1) Limits(2)]);
xticks(0:0.25:2);
ylim([Limits(3) Limits(4)]);
legend(['\tau < ',num2str(floor(TransitionTime(1)./10)),'[sec]'],...
    ['\tau > ',num2str(floor(TransitionTime(2)./10)),'[sec]']);

xlabel(['M3=','{\color{blue}',num2str(ParameterMat(3,1,1),'%.2f'),...
    ',\color{magenta}',num2str(ParameterMat(3,2,1),'%.2f'),...
    '\color{black} M4=','\color{blue}',num2str(ParameterMat(4,1,1),'%.2f'),...
    ',\color{magenta}',num2str(ParameterMat(4,2,1),'%.2f'),...
    '} '],'fontsize',14);
ylabel('probability','fontsize',14);
% define title string
TitlesInfo.titles={'\alpha_L_o_w','\alpha_H_i_g_h'};
title(['\fontsize{14} {\color{blue}',TitlesInfo.titles{1},'=',...
    num2str(ParameterMat(1,1,1),'%.2f'),...
    '\pm ',num2str(std(GeneralCoVec(:,1,1)),'%.2f'),...
    ' \color{magenta}',TitlesInfo.titles{2},'=',...
    num2str(ParameterMat(1,2,1),'%.2f'),...
    '\pm ',num2str(std(GeneralCoVec(:,1,2)),'%.2f'),...
    ' \color{black}; \sigma^2(',...
    ' \color{blue}',num2str(ParameterMat(2,1,1),'%.2f'),...
    ', \color{magenta}',num2str(ParameterMat(2,2,1),'%.2f'),')}']);
saveas(gcf,[ExperimentTitle,' AlphaHist Axial'],'bmp')

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
