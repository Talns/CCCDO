%% Main Function: UserParameter
% This function import user defined parameters. user should edit this file
% before running the analysis process
%% Function parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           idx:                    cell 1 by 2;
%                                   {1,1} phase index:
%                                   {1:'G0',2:'S',3:'G2',4:'LateG2',5:'UT'}
%                                   {1,2} Task index
%                                   {1:'MEF3T3',2:'MEFLmnaKO', 3:ensemble,
%                                   4:summary, 5-6: axillary call}
%           varargin:               additional inputs when needed according
%                                   to tasks: 
%                                   task 3: ensemble analysis.
%                                   index defines dimentionalty 
%                                   1- Axial 2- lateral 3- 3D full analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%          ExperimentFolder:        folder of the experiment
%          CellType:                cell lines name
%          ExcludedCells:           cell to be excluded from analysis
%          numCells:                number of cells
%          Phaseidx:                {1:'G0',2:'S',3:'G2',4:'LateG2',5:'UT'}
%          NumFrames:               number of frames in original image
%                                   sequence
%          MinLength:               Threshold for minimal length of a
%                                   trajectory
%          PhaseNames:              cell cycle phases. cell 1 by 5
%                                   {'G0','S','G2','LateG2','UT'}
%          CellTypeName:            cell line names.{'MEF3T3','MEFLmnaKO'} 
%          varargout:               additional outputs when needed                                   
%               ExcludeTrj:         explicitly call for QC 
%                                   struct with fields name "Cell_*' with
%                                   idx vector of the trajectories to be
%                                   deleted from analysis due to bad fit.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% script starts here %%

function [ExperimentFolder,CellType,ExcludedCells,...
    numCells,Phaseidx,NumFrames,MinLength,...
    PhaseNames,CellTypeName,varargout] = ...
    UserParameter(idx,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%% start of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%%%% Part A: general parameters %%%%%%%%%%%%%%%%%%%%%%%
% define number of frames in original image sequence
NumFrames = 1500;
% define threshold for minimal length of a trajectory
MinLength = 150;
% define the main folder for data storage and analysis 
ParentFolder = ['Q:\Data and code from papers\',...
            '2021 - Cell cycle dependent chromatin dynamic organization',...
            ' during the interphase\ExperimentalData'];
% cell cycle phase names          
PhaseNames= {'G0','S','G2','LateG2','UT'};
% cell lines names
CellTypeName={'MEF3T3','MEFLmnaKO'};
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%% %%%%% Part B: define parameters for specific phase experiment %%%%%%%%%% 
% here user souled define specific parameter of single cell analysis,
% as follow:
%  ExcludedCells:       cell to be excluded from analysis
%  numCells:            index; number of cells including excluded cells 
%  ExcludeTrj:          struct with fields name "Cell_*' with idx vector of
%                       the trajectories to be deleted from analysis due to
%                       bad fit.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch idx{1,2}
%% %%%%%%%%%%%%% task number 1: MEF3T3 single cell analysis %%%%%%%%%%%%%%%
    case 1
        switch idx{1,1}
            case 1
                %% %%%%%%%%%%%%%%%%%%%% MEF3T3 G0 %%%%%%%%%%%%%%%%%%%%%%%%%
                ExperimentFolder = ...
                    [ParentFolder,'\',CellTypeName{1,1},'_',PhaseNames{1,1}];
                CellType = CellTypeName{1,1};
                ExcludedCells = [1:5,8:17,20:25,28,30,32];
                numCells=34;
                Phaseidx=1;
                %%%%%%%%%%% define here trj indexes to be excluded %%%%%%%%
                ExcludeTrj=struct();
                ExcludeTrj.Cell_7 =[1];
                ExcludeTrj.Cell_19 =[6];
                ExcludeTrj.Cell_26 =[5];
                ExcludeTrj.Cell_27 =[4,10];
                ExcludeTrj.Cell_33 =[2,6];
                ExcludeTrj.Cell_34 =[1];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                varargout{1}=ExcludeTrj;
            case 2
                %% %%%%%%%%%%%%%%%% MEF3T3 S enrichment (S) %%%%%%%%%%%%%%%
                ExperimentFolder = ...
                    [ParentFolder,'\',CellTypeName{1,1},'_',PhaseNames{1,2}];
                CellType = CellTypeName{1,1};
                
                ExcludedCells = [1,2,8,10,11,15,23,25,28,35,39,40];
                numCells=41;
                Phaseidx=2;
                %%%%%%%%%%% define here trj indexes to be excluded %%%%%%%%
                ExcludeTrj=struct();
                ExcludeTrj.Cell_3 =[10,12];
                ExcludeTrj.Cell_4 =[19];
                ExcludeTrj.Cell_7 =[11];
                ExcludeTrj.Cell_13 =[1,13,16];
                ExcludeTrj.Cell_17 =[3];
                ExcludeTrj.Cell_20 =[3,9];
                ExcludeTrj.Cell_21 =[12];
                ExcludeTrj.Cell_24 =[2,4];
                ExcludeTrj.Cell_27 =[15];
                ExcludeTrj.Cell_30 =[8,15,20];
                ExcludeTrj.Cell_31 =[11,14];
                ExcludeTrj.Cell_34 =[18,20];
                ExcludeTrj.Cell_37 =[4];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                varargout{1}=ExcludeTrj;
            case 3
                %% %%%%%%%%%%%%%%%%%%%% MEF3T3 G2 %%%%%%%%%%%%%%%%%%%%%%%%%
                ExperimentFolder = ...
                    [ParentFolder,'\',CellTypeName{1,1},'_',PhaseNames{1,3}];
                CellType = CellTypeName{1,1};
                ExcludedCells = [2,6,13,14,17:22];
                numCells=26;
                Phaseidx=3;
                
               %%%%%%%%%%% define here trj indexes to be excluded %%%%%%%%%
                ExcludeTrj=struct();
                ExcludeTrj.Cell_4  = [1,3,5,6,11,15,16];
                ExcludeTrj.Cell_5  = [11,13];
                ExcludeTrj.Cell_7  = [3];
                ExcludeTrj.Cell_9  = [10,12];
                ExcludeTrj.Cell_10 = [2,19,20,21];
                ExcludeTrj.Cell_15 = [15,18,22];
                ExcludeTrj.Cell_16 = [11,17,19,22];
                ExcludeTrj.Cell_23 = [1,5,20,23];
                ExcludeTrj.Cell_25 = [3,5,6,7];
                ExcludeTrj.Cell_26 = [2,4,11,24,25,27];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                varargout{1}=ExcludeTrj;
                
            case 4
                %% %%%%%%%%%%%%%%%%% MEF3T3 Late G2  %%%%%%%%%%%%%%%%%%%%%%
                ExperimentFolder = [ParentFolder,'\',...
                    CellTypeName{1,1},'_',PhaseNames{1,4}];
                CellType = CellTypeName{1,1};
                ExcludedCells = [1:6,9:12,15:20,23:27,29,31:33,35,36];
                numCells=37;
                Phaseidx=4;
                %%%%%%%%%%% define here trj indexes to be excluded %%%%%%%%
                ExcludeTrj=struct();
                ExcludeTrj.Cell_7  = [14,17];
                ExcludeTrj.Cell_8  = [1,6,7,8];
                ExcludeTrj.Cell_13 = [1,3,5];
                ExcludeTrj.Cell_14 = [5,6,8,12,17,19,20,21];
                ExcludeTrj.Cell_21 = [10,12,25,28];
                ExcludeTrj.Cell_22 = [3];
                ExcludeTrj.Cell_25 = [3];
                ExcludeTrj.Cell_26 = [8];
                ExcludeTrj.Cell_28 = [8];
                ExcludeTrj.Cell_30 = [8,11,12];
                ExcludeTrj.Cell_34 = [5];
                ExcludeTrj.Cell_37 = [4,8,9,11,13,15];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                varargout{1}=ExcludeTrj;
            case 5
                %% %%%%%%%%%%%%%%%% MEF3T3 not treated (UT) %%%%%%%%%%%%%%%
                ExperimentFolder = ...
                    [ParentFolder,'\',CellTypeName{1,1},'_',PhaseNames{1,5}];
                CellType = CellTypeName{1,1};
                ExcludedCells = [10,11,13,14,24,25,28,32,33];
                numCells=36;
                Phaseidx=5;
                %%%%%%%%%%% define here trj indexes to be excluded %%%%%%%%
                ExcludeTrj=struct();
                ExcludeTrj.Cell_3  = [2,4,6,9,10];
                ExcludeTrj.Cell_5  = [2];
                ExcludeTrj.Cell_6  = [6];
                ExcludeTrj.Cell_7  = [3];
                ExcludeTrj.Cell_9  = [9];
                ExcludeTrj.Cell_12 = [4,7,8,10];
                ExcludeTrj.Cell_15 = [1,5,11];
                ExcludeTrj.Cell_18 = [1,12,14,15];
                ExcludeTrj.Cell_19 = [3,15];
                ExcludeTrj.Cell_20 = [3];
                ExcludeTrj.Cell_21 = [4,16,17];
                ExcludeTrj.Cell_22 = [2,3,12,14];
                ExcludeTrj.Cell_23 = [2,3,9];
                ExcludeTrj.Cell_26 = [1,3,12];
                ExcludeTrj.Cell_30 = [4,14,15];
                ExcludeTrj.Cell_34 = [1,3];
                ExcludeTrj.Cell_35 = [19];
                ExcludeTrj.Cell_36 = [3,4,5,9,12];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                varargout{1}=ExcludeTrj;
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%% end task number 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%% task number 2: MEFLmnaKO single cell analysis
    case 2
        switch idx{1,1}
            case 1
                %% %%%%%%%%%%%%%%%%%% MEFLmnaKO G0 %%%%%%%%%%%%%%%%%%%%%%%%
                ExperimentFolder = ...
                    [ParentFolder,'\',CellTypeName{1,2},'_',PhaseNames{1,1}];
                CellType = CellTypeName{1,2};
                ExcludedCells= [3,4,10,11,13:15,17:27,29:36,38,40];
                numCells=40;
                Phaseidx=1;
                %%%%%%%%%%% define here trj indexes to be excluded %%%%%%%%
                ExcludeTrj=struct();
                ExcludeTrj.Cell_1 = [1,26];
                ExcludeTrj.Cell_2 = [5,13,17,21,24];
                ExcludeTrj.Cell_5 = [1];
                ExcludeTrj.Cell_6 = [2,5,28,33];
                ExcludeTrj.Cell_8 = [4,7];
                ExcludeTrj.Cell_9 = [8,9];
                ExcludeTrj.Cell_39 = [4];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                varargout{1}=ExcludeTrj;
            case 2
                %% %%%%%%%%%%%%%%%%%% MEFLmnaKO S enrichment (S) %%%%%%%%%%
                ExperimentFolder = ...
                    [ParentFolder,'\',CellTypeName{1,2},'_',PhaseNames{1,2}];
                CellType = CellTypeName{1,2};
                ExcludedCells = [3,8:10,12:16,20,21,23,24,28,29,31];
                numCells=31;
                Phaseidx=2;
                %%%%%%%%%%% define here trj indexes to be excluded %%%%%%%%
                ExcludeTrj=struct();
                ExcludeTrj.Cell_1 = [2];
                ExcludeTrj.Cell_4 = [2,13];
                ExcludeTrj.Cell_6 = [22,26,28,31];
                ExcludeTrj.Cell_11 = [1,3,4,10];
                ExcludeTrj.Cell_19 = [1];
                ExcludeTrj.Cell_25 = [4,5];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                varargout{1}=ExcludeTrj;
            case 3
                %% %%%%%%%%%%%%%%%%%% MEFLmnaKO G2 %%%%%%%%%%%%%%%%%%%%%%%%
                ExperimentFolder = ...
                    [ParentFolder,'\',CellTypeName{1,2},'_',PhaseNames{1,3}];
                CellType = CellTypeName{1,2};
                ExcludedCells = [3,6,8,9,10,12,17,19,21:24,27:29,31,40];  
                numCells=40;
                Phaseidx=3;
                %%%%%%%%%%% define here trj indexes to be excluded %%%%%%%%
                ExcludeTrj=struct();
                ExcludeTrj.Cell_1 = [6];
                ExcludeTrj.Cell_4 = [46];
                ExcludeTrj.Cell_11 = [14,56,61,63,64];
                ExcludeTrj.Cell_14 = [27,35,39];
                ExcludeTrj.Cell_15 = [12,18,24,32:34];
                ExcludeTrj.Cell_25 = [31];
                ExcludeTrj.Cell_26 = [1,2];
                ExcludeTrj.Cell_30 = [8,13,15];
                ExcludeTrj.Cell_33 = [63];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                varargout{1}=ExcludeTrj;
            case 4
                %% %%%%%%%%%%%%%%%%% MEFLmnaKO Late G2  %%%%%%%%%%%%%%%%%%%
                ExperimentFolder = ...
                    [ParentFolder,'\',CellTypeName{1,2},'_',PhaseNames{1,4}];
                CellType = CellTypeName{1,2}; 
                ExcludedCells = [2,4:6,11,16:18,23,27:29]; 
                numCells=40;
                Phaseidx=4;
                %%%%%%%%%%% define here trj indexes to be excluded %%%%%%%%
                ExcludeTrj=struct();
                ExcludeTrj.Cell_3 =[33,48];
                ExcludeTrj.Cell_7 =[13,19,35];
                ExcludeTrj.Cell_8 =[7,18,29];
                ExcludeTrj.Cell_9 =[14];
                ExcludeTrj.Cell_10 =[26,33];
                ExcludeTrj.Cell_12 =[15,18];
                ExcludeTrj.Cell_13 =[40];
                ExcludeTrj.Cell_14 =[36];
                ExcludeTrj.Cell_20 =[42,49,64,70,73:75];
                ExcludeTrj.Cell_22 =[6,10,51];
                ExcludeTrj.Cell_26 =[12,59,60,63];
                ExcludeTrj.Cell_30 =[31:33];
                ExcludeTrj.Cell_33 =[29,34];
                ExcludeTrj.Cell_36 =[22,25];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                varargout{1}=ExcludeTrj;
            case 5
                %% %%%%%%%%%%%%%%%% MEFLmnaKO not treated (UT) %%%%%%%%%%%%
                ExperimentFolder = ...
                    [ParentFolder,'\',CellTypeName{1,2},'_',PhaseNames{1,5}];
                CellType = CellTypeName{1,2};
                ExcludedCells = [1,3,6:8,10,12:15,17:19,20,22:24,27,33];
                numCells=34;
                Phaseidx=5;
                %%%%%%%%%%% define here trj indexes to be excluded %%%%%%%%
                ExcludeTrj=struct();
                ExcludeTrj.Cell_2 =[24];
                ExcludeTrj.Cell_4 =[12,17];
                ExcludeTrj.Cell_9 =[12,17,21:25];
                ExcludeTrj.Cell_11 =[13];
                ExcludeTrj.Cell_16 =[9];
                ExcludeTrj.Cell_26 =[4,6,9];
                ExcludeTrj.Cell_28 =[29];
                ExcludeTrj.Cell_32 =[22];
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                varargout{1}=ExcludeTrj;
            otherwise
                errordlg('invalid phase index!');
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%% end task number 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%% %%%%%%%%%%%%%%%%%%%%%%% task number 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 3
        %% %%%%%%%% Part C: define folders for ensemble MSD %%%%%%%%%%%%%%%
        % user do not need to change any parameter in this section!
                
        switch varargin{1}
            case 1
                ExperimentFolder= ...
                    [ParentFolder,'\EnsembleAnalysis\Axial'];
            case 2
                ExperimentFolder= ...
                    [ParentFolder,'\EnsembleAnalysis\Lateral'];
            case 3
                ExperimentFolder= ...
                    [ParentFolder,'\EnsembleAnalysis\Full'];
            otherwise
                    ExperimentFolder = ParentFolder;
        end
        % data folderes path
        
        DATAFolders=cell(2,5);
        
       for i=1:2
           for j=1:5
               DATAFolders{i,j}=[ParentFolder,'\',...
                   CellTypeName{1,i},'_',PhaseNames{1,j}];
           end
       end
       CellType=[];
       ExcludedCells=[];
       numCells=[];
       Phaseidx=[];
       varargout{1}=DATAFolders;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% end task number 3 %%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%% task number 4: call from summary analysis %%%%%%%%%%%%%%%%%%       
    case 4
        %% Part D: specify time for calculate the constraining volume %%%%
        % time in sec
        TimeAve = 25;
        varargout{1}=TimeAve;
        % experiment folder 
        ExperimentFolder = [ParentFolder,'\EnsembleAnalysis'];
        % redundent parameters are empty
        CellType=[];
        ExcludedCells=[];
        numCells=[];
        Phaseidx=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% end task number 4 %%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%% task number 5: Axillary call from QC analysis table of statistic %%%       
    case 5
        %%  define parent data folder. 
        % user do not need to edit this section 
        varargout{1} = ParentFolder;
        % redundent parameters are empty
        CellType=[];
        ExcludedCells=[];
        numCells=[];
        Phaseidx=[];
        ExperimentFolder = ParentFolder;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% end task number 5 %%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%% task number 6: Axillary call from main %%%%%%%%%%%%%%%%%%%%%     
    case 6
        ExperimentFolder = ParentFolder;
        varargout{1} = ParentFolder;
        % redundent parameters are empty
        CellType=[];
        ExcludedCells=[];
        numCells=[];
        Phaseidx=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% end task number 6 %%%%%%%%%%%%%%%%%%%%%%%%%%        
    otherwise
        errordlg('invalid task index!');
end
%% add experiment folder to matlab path
addpath(ExperimentFolder);

%%%%%%%%%%%%%%%%%%%%%%%%%%% end of function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
